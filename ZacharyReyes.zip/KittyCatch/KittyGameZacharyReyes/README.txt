COMPILE:

The easiest way to run the game is to put it into eclipse and run main method from within the GameRun class.

CONTROLS:

Press Pause to pause game.
Press Quit to quit game.
Press Reset Lvl to reset level to original state.
Press Reset Dot to reset dot to original state (pressing space bar also works too).

Click anywhere on the screen to shoot cat towards that location.

The tools on the on the side of the screen can be picked up by clicking on them. Clicking again on somewhere
in the play area will make it so that picked up block will be placed in that location. Note that some locations are not possible
(like if two pieces intersect). If you're unhappy with the placement of an object, press and hold z while clicking it to pick it back up again.

Objects:
Spring: Bounces the cat with a strong force.
Ice: Allows the cat to slide across the ice.
Cannon: Allows the cat to get a secondary shot across the screen (click to shoot when cat is inside).
Mirror: Flips the world obstacles across the x axis when the cat hits it.

//KNOWN BUGS//
Currently, the main bug is if the dot collides with a corner of some obstacle, it can glitch out and traverse INSIDE that obstacle.
I've put in code to make sure that the dot will not be able to go dramatically outside the play area if such event occurs. I've updated the collision mechanics to help alleviate this issue.
Inside collisions still occur, but I've noticed that it happens at a much lower rate. Also, sometimes it feels like the cat HAS collided with the cannon, but the game doesn't pick this up.
It is probably an issue in that the image doesn't fit precisely with its collision region on screen.
DEVELOPER COMMENTS:

This iteration of the project is still imperfect. However, it feels a lot closer to what I wanted the game to be like when I first envisioned it. Some elements need tweaking, but overall,
there's a lot more control given to the player about how to reach the goal (and get the subgoals). As far as things I'd like to improve, I'd probably try to make some of the movement tighter, because
jumping feels a bit floaty. I'd also like to make a level editor (if I get around to it) so I can make levels faster. Finally, I'd like to improve the interplay of the game objects so the ideas feel more unified.
Right now, I feel like I accomplish that a little (try getting all of the kittens in each stage), but I think it could be better.

//CREDITS//

Benjamin Reyes created the soundtrack for my game.
I went to soundbible.com for most of the sound effects in my game.
The sound that plays when you collect a kitten is from the game franchise Fire Emblem.
Jacob Eddy played my game.