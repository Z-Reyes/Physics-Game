// GameRun.java
// Zachary Reyes, September 2017, borrowed from with minor changes from:
// Roger Mailler, January 2009, adapted from
// Andrew Davison, April 2005, ad@fivedots.coe.psu.ac.th

/* You are a green dot that is trying to make it to the goal (a yellow block) at the end of each level. 
 * You are able to click once in each level, which determines your initial x and y velocity.
 * You're also able to place blocks that can aid you in your goal.
 * 
 * Orange boxes are springs that give you a boost.
 * The blue boxes are low friction, meaning you can use them to traverse longer distances.
 * 

 -------------

 Uses full-screen exclusive mode, active rendering,
 and double buffering/page flipping.

 On-screen pause and quit buttons.

 Using Java 3D's timer: J3DTimer.getValue()
 *  nanosecs rather than millisecs for the period

 Average FPS / UPS
 20			50			80			100
 Win 98:         20/20       50/50       81/83       84/100
 Win 2000:       20/20       50/50       60/83       60/100
 Win XP (1):     20/20       50/50       74/83       76/100
 Win XP (2):     20/20       50/50       83/83       85/100

 Located in /BouncyDotFESM

 Updated: 12th Feb 2004
 * added extra sleep to the end of our setDisplayMode();

 * moved createBufferStrategy() call to a separate
 setBufferStrategy() method, with added extras
 ----
 */

/**
 * 
 */
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.StringTokenizer;

public class GameRun extends GameFrame {

	// The size of the playable character
	private final int SIZEX = 80;
	private final int SIZEY = 80;
	private final String LDIR = "/Levels/";

	// The region of the toolbox
	private final int TOOLBOXXLOW = 1526;
	private final int TOOLBOXXHIGH = 1920;
	private final int TOOLBOXYLOW = 55;
	private final int TOOLBOXYHIGH = 1030;

	// The play region of the game
	private final int PLAYAREAXLOW = 45;
	private final int PLAYAREAXHIGH = 1525;
	private final int PLAYAREAYLOW = 55;
	private final int PLAYAREAYHIGH = 1030;
	private final int CENTERLINE = 785;

	// Important objects and array for the game.
	private MazeObstacle[] listOfObstacles;
	private ImportantPoint[] listOfIP;
	private GoalPoint endGoal;

	// The file controllers.
	private StringBuilder filename;
	public StringBuilder prevFileName;
	private int points = 0;
	private boolean hitGoal = false;

	// boolean values to maintain state
	private boolean inProcess;
	private boolean gameComplete = false;
	private boolean pickUp;
	private MazeObstacle pickupAble;
	private int numNObstacles;
	private int xAcc;
	private int yAcc;
	private boolean isResettingLevel = false;
	private BufferedImage listOImages;
	private BufferedImage background;
	private int tickCounter = 0;
	private int frameCounter = 0;
	private boolean spaceKey;
	private boolean zKey;
	private ToolBox bob;

	// I don't know what this does
	private static final long serialVersionUID = -2450477630768116721L;

	private static int DEFAULT_FPS = 60;

	private PlayerBall player; // the player

	private ContextCursor pointer;
	private int pickUpIndex = 0;

	private int score = 0;
	private Font font;
	private Font font2 = new Font("", Font.BOLD, 30);
	// private FontMetrics metrics;

	// used by quit 'button'
	private volatile boolean isOverQuitButton = false;
	private volatile boolean isOverResetLvlButton = false;
	private volatile boolean isOverResetDotButton = false;
	private Rectangle quitArea;
	private Rectangle resetLvl;
	private Rectangle resetDot;
	private int dotStartingPosX;
	private int dotStartingPosY;
	// private Cannon te;
	// private Mirror ninn;

	// used by the pause 'button'
	private volatile boolean isOverPauseButton = false;
	private Rectangle pauseArea;

	private DecimalFormat df = new DecimalFormat("0.##"); // 2 dp

	public GameRun(long period) {
		super(period);
	}

	@Override
	protected void simpleInitialize() {
		bob = new ToolBox();

		bob.loadStaticImages();
		bob.storeAllThemes();
		// System.out.println(bob == null);
		// System.out.println(bob.getImageFromHash("SpringSprite").get(0) == null);
		// bob.loadContextData();
		// te = new Cannon(600, 800, 100, 100);
		// ninn = new Mirror(400, 800, 100, 100);

		filename = new StringBuilder("Level1X");
		// ToolBox.createInput("test.wav");
		// ToolBox.createOutput();

		prevFileName = new StringBuilder(filename.toString());

		// create game components
		// player = new PlayerBall(STARTX, STARTY, SIZEX, SIZEY, 0, 0, 0);
		// listOfObstacles = new MazeObstacle[4];
		pointer = new ContextCursor(10);
		pickUp = false;

		// o1 = new MazeObstacle(350, 1000, 2000, 20);
		// listOfObstacles[0] = o1;
		// o1 = new MazeObstacle(1350, 800, 200, 200);
		// listOfObstacles[1] = o1;
		// o1 = new MazeObstacle (150, 800, 200, 200);
		// listOfObstacles[2] = o1;
		// yoyo = new SpringObstacle(350, 300, 50, 50);
		// listOfObstacles[3] = yoyo;

		// player.setAccelerationX(1);

		readLevel(LDIR + filename.toString());

		// specify screen areas for the buttons
		pauseArea = new Rectangle(pWidth - 100, pHeight - 45, 70, 15);
		quitArea = new Rectangle(pWidth - 100, pHeight - 20, 70, 15);
		resetLvl = new Rectangle(pWidth - 350, pHeight - 975, 70, 15);
		resetDot = new Rectangle(pWidth - 250, pHeight - 975, 70, 15);
	}

	/**
	 * The isSpacedPressed method performs the same effect as clicking the reset dot
	 * button. The PlayerBall will return to its original spot, and any major world
	 * changes will be revoked.
	 */
	protected void isSpacedPressed() {
		if (spaceKey == false && !pickUp && !isPaused && !isResettingLevel) {
			player.setConstAccelerationX(0);
			player.setConstAccelerationY(0);
			player.resetAllValues();
			player.setAccelerationResist(30);
			inProcess = false;
			player.setxPos(dotStartingPosX);
			player.setyPos(dotStartingPosY);
			resetAllIP();
			spaceKey = true;
			player.setInCannon(false);
			this.resetMirrorWorld();
			points = 0;

		}
	}

	/**
	 * If the space key is released, set the spaceKey flag equal to false.
	 */
	protected void isSpaceReleased() {
		spaceKey = false;
	}

	/**
	 * The isZPressed method gives the permission for a placeable object to be moved
	 * again.
	 */
	protected void isZPressed() {
		if (zKey == false && !pickUp && !isPaused && !isResettingLevel && !inProcess) {
			zKey = true;
		}

	}

	/**
	 * If the Z key is released, set the zKey flag equal to false.
	 */
	protected void isZReleased() {
		zKey = false;
	}

	@Override
	protected void mousePress(int x, int y) {
		if (isPaused && hitGoal && !isResettingLevel) {
			score = score + points;
			points = 0;
			// System.out.println(filename);
			if (!gameComplete) {
				this.readLevel(LDIR + filename.toString());
				isPaused = false;
			} else {
				running = false;
			}
		} else if (isOverQuitButton)
			running = false;
		else if (isOverPauseButton && !pickUp && !isResettingLevel)
			isPaused = !isPaused; // toggle pausing
		else if (isOverResetLvlButton && !pickUp && !isPaused && !isResettingLevel) {
			resetLevel();

		} else if (isOverResetDotButton && !pickUp && !isPaused && !isResettingLevel) {

			player.setConstAccelerationX(0);
			player.setConstAccelerationY(0);
			player.resetAllValues();
			player.setAccelerationResist(30);
			inProcess = false;
			// System.out.println(dotStartingPosX);
			// System.out.println(dotStartingPosY);
			player.setxPos(dotStartingPosX);
			player.setyPos(dotStartingPosY);
			player.setInCannon(false);
			this.resetMirrorWorld();
			resetAllIP();

			points = 0;
		} else if (((x <= TOOLBOXXHIGH && x >= TOOLBOXXLOW && y <= TOOLBOXYHIGH && y >= TOOLBOXYLOW) || zKey == true)
				&& !isPaused && !pickUp && !inProcess && !isResettingLevel) {

			determineItem(x, y);

		} else if (x <= PLAYAREAXHIGH && x >= PLAYAREAXLOW && y <= PLAYAREAYHIGH && y >= PLAYAREAYLOW && !isPaused
				&& pickUp && !inProcess && !isResettingLevel) {
			// System.out.println("Attempting to place");
			this.isPlaceable();

		} else {

			if (!isPaused && !gameOver && !pickUp && !inProcess && !pickUp && !isResettingLevel) {
				// if (2 == 2) {

				// } else {

				// }
				player.calculateInitialMouseClick(x, y);
				// player.setConstAccelerationY(-1);
				player.setConstAccelerationX(xAcc);
				player.setConstAccelerationY(yAcc);
				inProcess = true;
				if (player.isInCannon() == true) {
					bob.getPlayer().playClip("CFire");
				} else {
					bob.getPlayer().playClip("meow");
				}
				// if (player.isInCannon() == true) {
				// player.setInCannon(false);
				// }

				// 1265
				// 380
			}
		}
	} // end of testPress()

	@Override
	protected void mouseMove(int x, int y) {

		// Added some code for pointer x and y
		pointer.setxPos(x);
		pointer.setyPos(y);
		if (running) { // stops problems with a rapid move after pressing 'quit'
			isOverPauseButton = pauseArea.contains(x, y) ? true : false;
			isOverQuitButton = quitArea.contains(x, y) ? true : false;
			isOverResetLvlButton = resetLvl.contains(x, y) ? true : false;
			isOverResetDotButton = resetDot.contains(x, y) ? true : false;

		}
		// Added some code for pickups
		if (pickUp) {
			pickupAble.setxPos(x);
			pickupAble.setyPos(y);
		}
	}

	@Override
	protected void simpleRender(Graphics gScr) {

		/*
		 * Draw all of the elements in the game.
		 */

		if (!isResettingLevel) {
			try {
				if (background != null) {
					gScr.drawImage(background, 0, 0, 1920, 1080, null);
				}
				gScr.setColor(Color.blue);
				gScr.setFont(font);
				gScr.setColor(Color.blue);
				gScr.setFont(font);

				// report frame count & average FPS and UPS at top left
				gScr.drawString("Average FPS/UPS: " + df.format(averageFPS) + ", " + df.format(averageUPS), 20, 25); // was
																														// (10,55)

				// report time used and boxes used at bottom left
				gScr.drawString("Time Spent: " + timeSpentInGame + " secs", 10, pHeight - 15);

				gScr.setColor(Color.WHITE);
				gScr.fillRect(1550, 30, 350, 1048);
				gScr.setColor(Color.BLACK);
				gScr.drawRect(1550, 30, 350, 1048);

				// draw the pause and quit 'buttons'
				drawButtons(gScr);

				drawAllObstacles(gScr);
				drawAllIP(gScr);
				endGoal.draw(gScr);
				// o1.draw(gScr);
				player.draw(gScr, tickCounter, pointer.getxPos(), pointer.getyPos());
				pointer.draw(gScr, pickUp);
				String message = "SCORE: " + points;
				gScr.setColor(Color.DARK_GRAY);
				gScr.setFont(font2);
				gScr.drawString(message, 1600, 80);

				StringBuilder yo = new StringBuilder("GRAVITY: ");
				// String yo = "GRAVITY: ";
				if (yAcc > 0) {
					yo.append("DOWN ");
				} else if (yAcc < 0) {
					yo.append("UP ");
				} else {
				}
				if (xAcc > 0) {
					yo.append("RIGHT");
				} else if (xAcc < 0) {
					yo.append("LEFT");
				} else {

				}
				if (yAcc == 0 && xAcc == 0) {
					yo.append("ZERO G");
				}
				// System.out.println(yAcc);
				// System.out.println(xAcc);
				gScr.setColor(Color.BLACK);
				gScr.drawString(yo.toString(), 1600, 1000);

				if (hitGoal) {
					this.gameOverMessage(gScr);
				}
				frameCounter = frameCounter + 1;

				if (frameCounter % DEFAULT_FPS == 0) {
					frameCounter = 0;
					tickCounter = 0;
				}

				if (frameCounter % (DEFAULT_FPS / 15) == 0) {
					tickCounter = tickCounter + 1;
				}
				// gScr.drawString(Integer.toString(frameCounter), 1550, 900);
				// gScr.drawString(Integer.toString(tickCounter), 1550, 950);
				// gScr.drawString(Double.toString(player.getxVelocity()), 1550, 800);
				// gScr.drawString(Double.toString(player.getyVelocity()), 1550, 850);
				// gScr.drawString(Integer.toString(player.getAccelerationY()), 1550, 750);
				// gScr.drawString(Boolean.toString(inProcess), 1550, 700);

				// te.draw(gScr);
				// ninn.draw(gScr);
			} catch (Exception e) {

			}
		}
		// drawAllObstacles(gScr);
	} // end of simpleRender()

	private void determineItem(int x, int y) {
		boolean found = false;
		int k = numNObstacles - 1;
		// System.out.println(listOfObstacles.length);
		while (!found && k < listOfObstacles.length - 1) {
			k = k + 1;
			// System.out.println(k);
			if (listOfObstacles[k].isIntersecting(x, y, x, y) && listOfObstacles[k].isActivated() == false) {
				found = true;
				// System.out.println("Found obstacle at position: " + k);
			}

		}
		if (found) {
			pickUp = true;
			pickupAble = listOfObstacles[k];
			pickUpIndex = k;
		}

	}

	/*
	 * The isPlaceable method determines whether a given section intersections with
	 * the currently 'picked' up item.
	 * 
	 */
	private void isPlaceable() {

		boolean intersects = false;

		for (int n = 0; n < listOfObstacles.length; n++) {

			if (pickUpIndex != n) {

				if (listOfObstacles[n].isIntersecting(pickupAble.getxPos(), pickupAble.getyPos(),
						pickupAble.getxPos() + pickupAble.getxSize(), pickupAble.getyPos() + pickupAble.getySize())) {
					//bob.getPlayer().playClip("error");
					intersects = true;
				}
				// if (listOfObstacles[n].isIntersecting(pickupAble.getxPos() +
				// pickupAble.getxSize(),
				// pickupAble.getyPos())) {
				// intersects = true;
				// }
				// if (listOfObstacles[n].isIntersecting(pickupAble.getxPos(),
				// pickupAble.getyPos() + pickupAble.getySize())) {
				// intersects = true;
				// }
				// if (listOfObstacles[n].isIntersecting(pickupAble.getxPos() +
				// pickupAble.getxSize(),
				// pickupAble.getyPos() + pickupAble.getySize())) {
				// intersects = true;
				// }
			}

		}
		if (!intersects) {
			
			//System.out.println("made it");
			pickUp = false;
			// System.out.println("Successful placement");
		}

	}

	/*
	 * The drawAllIP method is a method that sequentially draws all of the obstacles
	 * within the listOfIP array.
	 * 
	 */
	private void drawAllIP(Graphics gui) {
		for (int i = 0; i < listOfIP.length; i++) {
			listOfIP[i].draw(gui, tickCounter);
		}
	}

	/*
	 * The drawAllObstacles method is a method that sequentially draws all of the
	 * obstacles within the listOfObstacles array.
	 */
	protected void drawAllObstacles(Graphics gui) {
		for (int i = 0; i < listOfObstacles.length; i++) {
			listOfObstacles[i].draw(gui);
		}
	}

	// This method will reset the level.
	private void resetLevel() {
		String tempString = prevFileName.toString();
		points = 0;
		// System.out.println("HERE IS PREVFILENAME VALUE: " + prevFileName);
		readLevel(LDIR + prevFileName.toString());
		prevFileName.delete(0, prevFileName.length());
		prevFileName.append(tempString);
	}

	/*
	 * The drawButtons method is simply a method that draws the buttons in the lower
	 * half end of the screen. A highlighted button will appear green to notify the
	 * user that it is clickable. Otherwise, it is black.
	 */
	private void drawButtons(Graphics g) {
		g.setColor(Color.black);

		// draw the pause 'button'
		if (isOverPauseButton)
			g.setColor(Color.green);

		g.drawOval(pauseArea.x, pauseArea.y, pauseArea.width, pauseArea.height);
		if (isPaused)
			g.drawString("Paused", pauseArea.x, pauseArea.y + 10);
		else
			g.drawString("Pause", pauseArea.x + 5, pauseArea.y + 10);

		if (isOverPauseButton)
			g.setColor(Color.black);

		// draw the quit 'button'
		if (isOverQuitButton)
			g.setColor(Color.green);

		g.drawOval(quitArea.x, quitArea.y, quitArea.width, quitArea.height);
		g.drawString("Quit", quitArea.x + 15, quitArea.y + 10);

		if (isOverResetLvlButton) {
			g.setColor(Color.GREEN);
		} else {
			g.setColor(Color.BLACK);
		}
		g.drawOval(resetLvl.x, resetLvl.y, resetLvl.width, resetLvl.height);
		g.drawString("Reset Lvl", resetLvl.x + 6, resetLvl.y + 12);

		if (isOverResetDotButton) {
			g.setColor(Color.GREEN);
		} else {
			g.setColor(Color.BLACK);
		}
		g.drawOval(resetDot.x, resetDot.y, resetDot.width, resetDot.height);
		g.drawString("Reset Cat", resetDot.x + 6, resetDot.y + 12);

		if (isOverQuitButton)
			g.setColor(Color.black);
	} // drawButtons()

	@Override
	protected void gameOverMessage(Graphics g)
	// center the game-over message in the panel
	{
		this.pauseGame();

		// int tempHolderScore = points;
		// points = 0;
		g.setColor(Color.WHITE);
		g.setFont(font);

		String msg;
		String msg2;

		if (filename.toString().equals("END")) {
			gameComplete = true;
			msg = "You have completed all levels with a final score of: " + (points + score);
			msg2 = "Hope you had a great time playing! Click anywhere to exit the game.";

		} else {
			msg = "Congratulations!\nYou have completed the level with this score: " + points;
			msg2 = "Click anywhere to go to " + filename;
		}
		g.fillRect(150, 300, 1200, 125);
		g.setColor(Color.BLACK);
		g.drawRect(150, 300, 1200, 125);
		g.drawString(msg, 200, 350);
		g.drawString(msg2, 200, 350 + g.getFontMetrics().getHeight());
	} // end of gameOverMessage()

	private void reverseAllObstacles() {

		// System.out.println("Num of obstacles: " + numNObstacles);
		try {
			for (int m = 4; m < listOfObstacles.length; m++) {
				int x = listOfObstacles[m].getxPos();
				int y = listOfObstacles[m].getyPos();
				if (x <= PLAYAREAXHIGH + 5 && x >= PLAYAREAXLOW - 5 && y <= PLAYAREAYHIGH + 5
						&& y >= PLAYAREAYLOW - 5) {
					int centerPosX = (listOfObstacles[m].getxPos() + (listOfObstacles[m].getxSize() / 2));
					int diffx = Math.abs(CENTERLINE - centerPosX);
					if (centerPosX < CENTERLINE) {
						listOfObstacles[m].setxPos((CENTERLINE + diffx) - ((listOfObstacles[m].getxSize() / 2)));
					} else if (centerPosX > CENTERLINE) {
						listOfObstacles[m].setxPos((CENTERLINE - diffx) - ((listOfObstacles[m].getxSize() / 2)));
					}
				}
			}
		} catch (Exception e) {
			System.out.println("UGHHHHHH");
		}
	}

	private void resetIsActivatedAndIsDead() {
		for (int i = 0; i < listOfObstacles.length; i++) {
			listOfObstacles[i].setActivated(false);
			listOfObstacles[i].setDead(false);
		}
	}

	@Override
	protected void simpleUpdate() {

		try {
			this.checkDot();
			// boolean found = false;

			if (!isResettingLevel) {
				// System.out.println(player == null);
				if (player.isInCannon() == true && player.getxVelocity() == 0 && player.getyVelocity() == 0) {
					inProcess = false;
					player.setAccelerationResist(30);
				}
				int n = listOfObstacles.length;
				// System.out.println("HereWeGo");
				// System.out.println(n);
				int o = 0;
				boolean leftFound = false;
				boolean rightFound = false;
				boolean upFound = false;
				boolean downFound = false;
				boolean upRightFound = false;
				boolean upLeftFound = false;
				boolean downRightFound = false;
				boolean downLeftFound = false;

				// Repeat until you've traversed the entire list.
				while (o < n) {

					player.getRightSensor().calculateIntersect(listOfObstacles[o]);
					if (player.getRightSensor().isIntersection() == true) {
						rightFound = true;
					}

					player.getLeftSensor().calculateIntersect(listOfObstacles[o]);
					if (player.getLeftSensor().isIntersection() == true) {
						leftFound = true;
					}

					player.getUpSensor().calculateIntersect(listOfObstacles[o]);
					if (player.getUpSensor().isIntersection() == true) {
						upFound = true;
					}

					player.getDownSensor().calculateIntersect(listOfObstacles[o]);
					if (player.getDownSensor().isIntersection() == true) {
						downFound = true;
					}

					player.getUpRightSensor().calculateIntersect(listOfObstacles[o]);
					if (player.getUpRightSensor().isIntersection() == true) {
						upRightFound = true;
					}
					player.getUpLeftSensor().calculateIntersect(listOfObstacles[o]);
					if (player.getUpLeftSensor().isIntersection() == true) {
						upLeftFound = true;
					}
					player.getDownRightSensor().calculateIntersect(listOfObstacles[o]);
					if (player.getDownRightSensor().isIntersection() == true) {
						downRightFound = true;
					}
					player.getDownLeftSensor().calculateIntersect(listOfObstacles[o]);
					if (player.getDownLeftSensor().isIntersection() == true) {
						downLeftFound = true;
					}

					listOfObstacles[o].collision(player, player.getLeftSensor().isIntersection(),
							player.getRightSensor().isIntersection(), player.getUpSensor().isIntersection(),
							player.getDownSensor().isIntersection(), player.getUpRightSensor().isIntersection(),
							player.getUpLeftSensor().isIntersection(), player.getDownRightSensor().isIntersection(),
							player.getDownLeftSensor().isIntersection(), bob.getPlayer(), pointer);
					if (listOfObstacles[o].getClass() == Mirror.class) {
						if (listOfObstacles[o].isActivated() == true && listOfObstacles[o].isDead() == false) {
							this.reverseAllObstacles();
							listOfObstacles[o].setDead(true);

						}
						// System.out.println(listOfObstacles[o].getClass());
					}
					// player.getUpRightSensor().calculateIntersect(o1);
					// player.getUpLeftSensor().calculateIntersect(o1);
					// player.getDownLeftSensor().calculateIntersect(o1);
					// player.getDownRightSensor().calculateIntersect(o1);
					o = o + 1;
					// System.out.println("O has been incremented");
					// System.out.println(o);
				}
				// te.collision(player, player.getLeftSensor().isIntersection(),
				// player.getRightSensor().isIntersection(),
				// player.getUpSensor().isIntersection(),
				// player.getDownSensor().isIntersection(),
				// player.getUpRightSensor().isIntersection(),
				// player.getUpLeftSensor().isIntersection(),
				// player.getDownRightSensor().isIntersection(),
				// player.getDownLeftSensor().isIntersection());

				// if (ninn.isDead() == false) {
				// ninn.collision(player, player.getLeftSensor().isIntersection(),
				// player.getRightSensor().isIntersection(),
				// player.getUpSensor().isIntersection(),
				// player.getDownSensor().isIntersection(),
				// player.getUpRightSensor().isIntersection(),
				// player.getUpLeftSensor().isIntersection(),
				// player.getDownRightSensor().isIntersection(),
				// player.getDownLeftSensor().isIntersection());
				// if (ninn.isActivated() == true) {
				// this.reverseAllObstacles();
				// System.out.println("Reversed all obstacles");
				// ninn.setDead(true);
				// }
				// }

				player.setPrevLeftCollision(leftFound && !rightFound);
				player.setPrevRightCollision(!leftFound && rightFound);
				player.setPrevUpCollision(upFound && !downFound);
				player.setPrevDownCollision(!upFound && downFound);
				if (!leftFound && !rightFound && !downFound && !upFound) {
					player.setContact(false);
				}

				// if ((player.isPrevLeftCollision() || player.isPrevDownCollision() ||
				// player.isPrevRightCollision() || player.isPrevUpCollision()) && list) {

				// }

				player.setPrevUpRightCollision(upRightFound && !leftFound && !rightFound && !downFound && !upFound
						&& !downRightFound && !upLeftFound && !downLeftFound);
				player.setPrevUpLeftCollision(!upRightFound && !leftFound && !rightFound && !downFound && !upFound
						&& !downRightFound && upLeftFound && !downLeftFound);
				player.setPrevDownRightCollision(!upRightFound && !leftFound && !rightFound && !downFound && !upFound
						&& downRightFound && !upLeftFound && !downLeftFound);
				player.setPrevDownLeftCollision(!upRightFound && !leftFound && !rightFound && !downFound && !upFound
						&& !downRightFound && !upLeftFound && downLeftFound);
				// player.setPrevLeftCollision(leftFound && !rightFound && !upRightFound &&
				// !downRightFound && (upLeftFound || downLeftFound));
				// player.setPrevRightCollision(rightFound && !leftFound && !upLeftFound &&
				// !downLeftFound && (upRightFound || downRightFound));
				// player.setPrevDownCollision(downFound && !upFound && !upRightFound &&
				// !upLeftFound && (downRightFound || downLeftFound));
				// player.setPrevUpCollision(upFound && !downFound && !downRightFound &&
				// !downLeftFound && (upRightFound || upLeftFound)) ;

				int l = listOfIP.length;

				for (int b = 0; b < l; b++) {
					if (player.intersecting(listOfIP[b].getxPos(), listOfIP[b].getyPos(),
							listOfIP[b].getxPos() + listOfIP[b].getxSize(),
							listOfIP[b].getyPos() + listOfIP[b].getySize())) {
						if (listOfIP[b].isDetected() == false) {
							bob.getPlayer().playClip("powerUp");
						}
						points += listOfIP[b].applyPoints();

					}
				}
				if (player.intersecting(endGoal.getxPos(), endGoal.getyPos(), endGoal.getxPos() + endGoal.getxSize(),
						endGoal.getyPos() + endGoal.getySize())) {
					// System.out.println("Hit the Goal");
					// this.endGoalEvent();
					hitGoal = true;

				}

				// player.collisionDetectionSlow(leftFound, rightFound, upFound, downFound);
				// if (player.getxVelocity() == 15) {
				// player.setAccelerationX(0);
				// }
				player.updateNextInterval();
			}
		} catch (Exception e) {
			System.out.println(e);
			// System.out.println(""));
		}
		// updateAcc();
	}

	private void resetMirrorWorld() {
		for (int i = 0; i < listOfObstacles.length; i++) {
			if (listOfObstacles[i].getClass() == Mirror.class && listOfObstacles[i].isDead() == true) {
				listOfObstacles[i].setDead(false);
				listOfObstacles[i].setActivated(false);
				this.reverseAllObstacles();
			}
		}
	}

	// This code jsut checks that the player is within the player area. It's used
	// for just in case the player's physics messes up.
	private void checkDot() {
		if (player != null) {
			if (player.getxPos() > PLAYAREAXHIGH + 50 || player.getxPos() < PLAYAREAXLOW - 50
					|| player.getyPos() < PLAYAREAYLOW - 50 || player.getyPos() > PLAYAREAYHIGH + 50) {
				player.resetAllValues();
				// System.out.println("Dot is outside Range");
			}
		} else {
			System.out.println("UH OH");
		}
	}

	/*
	 * 
	 */
	/**
	 * The readlevel method reads the formatted input files and uses the elements
	 * within the file to create a level for the game.
	 * 
	 * @param fileN
	 *            The string representing the level name.
	 */
	protected void readLevel(String fileN) {
		isResettingLevel = true;
		hitGoal = false;

		try {
			System.out.println(fileN);

			File h8 = new File(fileN);
			BufferedReader test = new BufferedReader(new InputStreamReader(GameRun.class.getResourceAsStream(fileN)));

			/*
			 * Create obstacles.
			 */
			String temp = test.readLine();
			StringTokenizer tk = new StringTokenizer(temp);
			// ToolBox.setThemedWorld(0);
			int world = Integer.parseInt(tk.nextToken());
			// System.out.println(bob == null);
			// System.out.println(world);
			bob.setThemedWorld(world);

			// System.out.println("Bout to get the music");
			bob.playBackground(); // This line is the issue!!!!
			// System.out.println("Bout to get correctBackground");
			background = bob.getCorrectBackground();

			temp = test.readLine();
			tk = new StringTokenizer(temp);
			int numRepeats = Integer.parseInt(tk.nextToken());

			listOfObstacles = new MazeObstacle[numRepeats];
			numNObstacles = Integer.parseInt(tk.nextToken());

			// System.out.println("Starting reading obstacles.");
			// Load in all objects
			int indexStart = 0;
			for (int k = 0; k < 5; k++) {
				String val = test.readLine();

				indexStart = loadInObjects(k, indexStart, val);

			}

			// System.out.println("Made it past obstacles");
			// Ready crying kitty objects
			temp = test.readLine();
			tk = new StringTokenizer(temp);
			int num = Integer.parseInt(tk.nextToken());
			listOfIP = new ImportantPoint[num];
			for (int k = 0; k < num; k++) {
				int x1 = Integer.parseInt(tk.nextToken());
				int y1 = Integer.parseInt(tk.nextToken());
				int s1 = Integer.parseInt(tk.nextToken());
				int s2 = Integer.parseInt(tk.nextToken());

				listOfIP[k] = new ImportantPoint(x1, y1, s1, s2, bob);
			}

			/*
			 * Get the location of the dot hero.
			 */
			// System.out.println("Made it past kitties");
			temp = test.readLine();
			tk = new StringTokenizer(temp);
			dotStartingPosX = Integer.parseInt(tk.nextToken());
			dotStartingPosY = Integer.parseInt(tk.nextToken());
			player = new PlayerBall(dotStartingPosX, dotStartingPosY, SIZEX, SIZEY, 0, 0, 0, bob);

			/*
			 * Get the importantValues
			 */

			/*
			 * Get the goal point
			 */
			temp = test.readLine();
			tk = new StringTokenizer(temp);
			int x2 = Integer.parseInt(tk.nextToken());
			int y2 = Integer.parseInt(tk.nextToken());
			int s3 = Integer.parseInt(tk.nextToken());
			int s4 = Integer.parseInt(tk.nextToken());
			endGoal = new GoalPoint(x2, y2, s3, s4, bob);

			temp = test.readLine();
			tk = new StringTokenizer(temp);
			xAcc = Integer.parseInt(tk.nextToken());
			yAcc = Integer.parseInt(tk.nextToken());

			// Get the name of the next file or END
			// prevFileName = filename.substring(0, filename.length());
			prevFileName.delete(0, prevFileName.length());
			prevFileName.append(filename.toString());
			temp = test.readLine();

			filename.delete(0, filename.length());
			// if (temp.equals("END")) {
			filename.append(temp);
			// } else {
			// filename = "./" + temp;
			// filename.append("./" + temp);
			// }
			// System.out.println(prevFileName);
			System.out.println(filename);

			isResettingLevel = false;
			inProcess = false;

			pickUp = false;
			player.resetAllValues();
			player.setAccelerationResist(30);
			test.close();

		} catch (Exception e) {
			System.out.println(e);
			System.out.println("BAD FILEREAD");
			running = false;
		}

	}

	private int loadInObjects(int key, int con, String line) {
		if (line.startsWith("/", 0)) {
			return con;
		} else {
			StringTokenizer tk = new StringTokenizer(line);
			try {
				int ending = con + Integer.parseInt(tk.nextToken());
				while (con < ending) {
					int xx = Integer.parseInt(tk.nextToken());
					int yy = Integer.parseInt(tk.nextToken());
					int sxx = Integer.parseInt(tk.nextToken());
					int syy = Integer.parseInt(tk.nextToken());

					MazeObstacle ob;
					switch (key) {
					case 0:
						ob = new MazeObstacle(xx, yy, sxx, syy, bob);
						break;
					case 1:
						ob = new SpringObstacle(xx, yy, sxx, syy, bob);
						break;
					case 2:
						ob = new IcyObstacle(xx, yy, sxx, syy, bob);
						break;
					case 3:
						ob = new Cannon(xx, yy, sxx, syy, bob);
						break;
					case 4:
						ob = new Mirror(xx, yy, sxx, syy, bob);
						break;
					default:
						ob = new MazeObstacle(1, 1, 1, 1, bob);
						break;
					}
					listOfObstacles[con] = ob;
					con = con + 1;
				}
				return con;
			} catch (Exception e) {
				System.out.println("Something went wrong with loading the objects from the file");
				System.out.println(e);
				return con;
			}
		}

	}

	// This code resets the existence value of all important values.
	private void resetAllIP() {

		for (int j = 0; j < listOfIP.length; j++) {
			listOfIP[j].setDetected(false);
		}
	}

	/*
	 * Our main method simply starts the game.
	 */
	public static void main(String args[]) {
		int fps = DEFAULT_FPS;
		if (args.length != 0)
			fps = Integer.parseInt(args[0]);

		long period = (long) 1000.0 / fps;
		System.out.println("fps: " + fps + "; period: " + period + " ms");
		new GameRun(period * 1000000L); // ms --> nanosecs
	} // end of main()

} // end of WormChase class
