import java.awt.image.BufferedImage;

/**
 * The BBElement is a basic element of this game. It contains the major properties that every element in the game should have.
 * 
 * @author Zachary Reyes
 *
 */
public class BBElement {
	
	
	private final int MAXSPEEDX = 15;
	
	private int xPos;
	private int yPos;
	private int xSize;
	private int ySize;
	private double xVelocity;
	private double yVelocity;
	private BufferedImage myImage;
	

	/**
	 * @return the myImage
	 */
	public BufferedImage getMyImage() {
		return myImage;
	}

	/**
	 * @param myImage the myImage to set
	 */
	public void setMyImage(BufferedImage myImage) {
		this.myImage = myImage;
	}

	/**
	 * @return the xPos
	 */
	public int getxPos() {
		return xPos;
	}

	/**
	 * @param xPos the xPos to set
	 */
	public void setxPos(int xPos) {
		this.xPos = xPos;
	}

	/**
	 * @return the yPos
	 */
	public int getyPos() {
		return yPos;
	}

	/**
	 * @param yPos the yPos to set
	 */
	public void setyPos(int yPos) {
		this.yPos = yPos;
	}

	/**
	 * @return the xSize
	 */
	public int getxSize() {
		return xSize;
	}

	/**
	 * @param xSize the xSize to set
	 */
	public void setxSize(int xSize) {
		this.xSize = xSize;
	}

	/**
	 * @return the ySize
	 */
	public int getySize() {
		return ySize;
	}

	/**
	 * @param ySize the ySize to set
	 */
	public void setySize(int ySize) {
		this.ySize = ySize;
	}


	/**
	 * 
	 * @param xVelocity the xVelocity to set
	 * 
	 * The setxVelocity method sets the xVelocity to the first parameter value. If xVelocity would become greater than the max speed, then xVelocity will be set to the maxspeed.
	 */
	public void setxVelocity(double xVelocity) {
		int right = determineDirection(xVelocity);
		if (Math.abs(xVelocity) < MAXSPEEDX) {
		this.xVelocity = xVelocity;
		} else {
			this.xVelocity = (MAXSPEEDX * right);
		}
	}

	
	/**
	 * @return the xVelocity
	 */
	public double getxVelocity() {
		return xVelocity;
	}

	/**
	 * @return the yVelocity
	 */
	public double getyVelocity() {
		return yVelocity;
	}

	/**
	 * 
	 * @param yVelocity the yVelocity to set
	 * The setxVelocity method sets the yVelocity to the first parameter value. If xVelocity would become greater than the max speed, then yVelocity will be set to the maxspeed.
	 */
	public void setyVelocity(double yVelocity) {
		
		int down = determineDirection(yVelocity);
		if (Math.abs(yVelocity) < MAXSPEEDX) {
		this.yVelocity = yVelocity;
		} else {
			this.yVelocity = (MAXSPEEDX * down);
		}
	}
	
	
	private int determineDirection(double test) {
		int positive = 1;
		if (test < 0) {
			positive = -1;
		}
		return positive;
	}
	
	/**
	 * The updateXPos method updates the xPos using the xVelocity
	 */
	public void updateXpos() {
		
		xPos = xPos + (int) xVelocity;
	}
	/**
	 * The updateYPos method updates the yPos using the yVelocity
	 */
	public void updateYpos() {
		yPos = yPos + (int) yVelocity;
	}

	
	/**
	 * 
	 * @param x is the initial x position
	 * @param y is the initial y position
	 * @param sx is the width of the BBElement
	 * @param sy is the height of the BBElement
	 * 
	 * The BBElement contructor builds a new BBElement for the game. 
	 */
	public BBElement(int x, int y, int sx, int sy) {
		
		xPos = x;
		yPos = y;
		xSize = sx;
		ySize = sy;
		
	}
	
	/**
	 * The default contructor for BBElement simply creates a dot BBElement at position (1, 1).
	 */
	public BBElement() {
		xPos = 1;
		yPos = 1;
		xSize = 1;
		ySize = 1;
		
	}
	/**
	 * @return the mAXSPEEDX
	 */
	public int getMAXSPEEDX() {
		return MAXSPEEDX;
	}
	
	/**
	 * Just a simple method declaration that is overloaded in subclasses
	 * @param j the PlayerBall to be checked for collision.
	 */
	public void collision(PlayerBall j) {}
	
	

	
	

}
