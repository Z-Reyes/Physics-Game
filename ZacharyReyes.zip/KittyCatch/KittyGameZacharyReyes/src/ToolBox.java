import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;

import javax.sound.sampled.*;

import javax.imageio.*;
/**
 * The ToolBox class is used for the ToolBox object. It is used in our game to load and use images in the game.
 * @author Zachary Reyes
 *
 */
public class ToolBox {

	// private String[] listOfImages;
	private  AudioInputStream stream;
	private  AudioFormat format = null;
	private  SourceDataLine line = null;
	private AudioController player;
	private final String STATICDIR = "/StaticImages/";
	private HashMap<String, ArrayList<BufferedImage>> imagesList;
	private int themedWorld = 0;
	//private static int numBoundBlocks = 0;
	private  String themeName = "";
	private final int numThemes = 3;

	/**
	 * The constructor for our toolBox object.
	 */
	public ToolBox () {
		imagesList = new HashMap<String, ArrayList<BufferedImage>>();
		player = new AudioController();
	}
	/**
	 * @return the player
	 */
	public AudioController getPlayer() {
		return player;
	}

	/**
	 * @param player the player to set
	 */
	public void setPlayer(AudioController play) {
		player = play;
	}

	/**
	 * @return the themedWorld
	 */
	public int getThemedWorld() {
		return themedWorld;
	}

	/**
	 * @param themedWorld
	 *            the themedWorld to set NOTE: Use only when you want to read a new
	 *            level.
	 */
	public void setThemedWorld(int tH) {

		themedWorld = tH;
		//numBoundBlocks = 0;
		setThemeName();
	}

	private void setThemeName() {
		switch (themedWorld) {
		case 0:
			themeName = "KKFL";
			break;
		case 1:
			themeName = "ML";
			break;
		case 2:
			themeName = "HLL";
			break;
		default:
			break;
		}
	}

	/**
	 * Plays the background depending on the enumeration of themeName
	 */
	public void playBackground() {
		player.playBackground(themeName);
	}
	/**
	 * The getBoundaryBlock method is used to automatically return the correct MazeObstacle image for a given MazeObstacle.
	 * @param jk The MazeObstacle object is used to determine which version of the MazeObstacle image is returned.
	 * @return The correct MazeObstacle image. Or null if cannot find.
	 */
	public BufferedImage getBoundaryBlock(MazeObstacle jk) {

		//switch (numBoundBlocks) {
		//case 0:
			//System.out.println(numBoundBlocks);
		//	numBoundBlocks += 1;
		//	return getCorrectBoundary("FirstB");
		//case 1:
			//System.out.println(numBoundBlocks);
		//	numBoundBlocks += 1;
		//	return getCorrectBoundary("SecondB");
		//case 2:
			//System.out.println(numBoundBlocks);
		//	numBoundBlocks += 1;
		//	return getCorrectBoundary("ThirdB");
		//case 3:
			//System.out.println(numBoundBlocks);
		//	numBoundBlocks += 1;
		//	return getCorrectBoundary("FourthB");
		//default:
			//System.out.println(numBoundBlocks);
			if (jk.getxSize() > jk.getySize()){
				return getCorrectBoundary("WideB");
			} else {
				return getCorrectBoundary("TallB");
			}
			

		//}

	}
	/**
	 * The getCorrectBackground method returns the correct background image based on the ToolBox's theme state
	 * @return The correct background image. Or null if cannot locate.
	 */
	public  BufferedImage getCorrectBackground() {
		return getImageFromHash(themeName + "Background").get(0);
	}
	/**
	 * The storeAllThemes method stores each of the theme components (background and MazeObstacle blocks) for all of the themes into memory.
	 */
	public  void storeAllThemes() {
		//Store the themed images.
		for (int m = 0; m < numThemes; m++) {
			//System.out.println(themeName + "BannerEdgeHS.png");
			setThemedWorld(m);
			//System.out.println(m);
			//System.out.println(themeName);
			BufferedImage temp;
			ArrayList<BufferedImage> list;
			//BufferedImage temp = getIm(themeName + "/BannerEdgesHS.png");
			//ArrayList<BufferedImage> list = new ArrayList<BufferedImage>();
			//list.add(temp);
			//imagesList.put(themeName + "FirstB",list);
			
			//temp = getIm(themeName + "/BannerEdgesHL.png");
			//list = new ArrayList<BufferedImage>();
			//list.add(temp);
			//imagesList.put(themeName + "SecondB", list);
			
			//temp = getIm(themeName + "/BannerEdgesVL.png");
			//list = new ArrayList<BufferedImage>();
			//list.add(temp);
			//imagesList.put(themeName + "ThirdB", list);
			
			//temp = getIm(themeName + "/BannerEdgesVS.png");
			//list = new ArrayList<BufferedImage>();
			//list.add(temp);
			//imagesList.put(themeName + "FourthB", list);
			
			temp = getIm(themeName + "/BannerEdgesHL.png");
			list = new ArrayList<BufferedImage>();
			list.add(temp);
			imagesList.put(themeName + "WideB", list);
			
			temp = getIm(themeName + "/BannerEdgesVL.png");
			list = new ArrayList<BufferedImage>();
			list.add(temp);
			imagesList.put(themeName + "TallB", list);
			
			temp = getIm(themeName + "/Background.png");
			list = new ArrayList<BufferedImage>();
			list.add(temp);
			imagesList.put(themeName + "Background", list);
			
		}
	}

	private BufferedImage getCorrectBoundary(String yo) {
		
		return getImageFromHash(themeName + yo).get(0);

	}

	// private BufferedImage getCorrectWorldBlock(int k) {

	// }

	private BufferedImage getIm(String path) {
		System.out.println(path);
		try {
			return ImageIO.read(ToolBox.class.getResource(path));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Cannot find image.");
			// e.printStackTrace();

			return null;
		}

	}
/**
 * The loadStaticImages method loads all of the constant image components into memory and the hash table.
 */
	public void loadStaticImages() {
		imagesList = new HashMap<String, ArrayList<BufferedImage>>();
		try {
			/*
			 * Put in the spring image.
			 */
			BufferedImage mailler = getIm(STATICDIR + "Spring.png");
			ArrayList<BufferedImage> maillerList = new ArrayList<BufferedImage>();
			maillerList.add(mailler);
			imagesList.put("SpringSprite", maillerList);

			mailler = getIm(STATICDIR + "IceTest2.png");
			maillerList = new ArrayList<BufferedImage>();
			maillerList.add(mailler);
			imagesList.put("IceSprite", maillerList);

			// UNUSED PROGRAM
			//mailler = getIm(STATICDIR + "CatTower.png");
			//maillerList = new ArrayList<BufferedImage>();
			//maillerList.add(mailler);
			//imagesList.put("CatTowerSprite", maillerList);

			/*
			 * Put in crying kitty animation.
			 */
			maillerList = loadStrip(STATICDIR + "CryingKitty.png", 4);
			imagesList.put("CryingKitty", maillerList);

			maillerList = loadStrip(STATICDIR + "CatFacePlant.png", 3);
			imagesList.put("CatFacePlant", maillerList);

			maillerList = loadStrip(STATICDIR + "CatJumpAnimation.png", 9);
			imagesList.put("CatJumping", maillerList);
			ArrayList<BufferedImage> temp = new ArrayList<BufferedImage>();
			temp.add(maillerList.get(0));
			imagesList.put("CatStanding", temp);
			temp = null;
			maillerList = loadStrip(STATICDIR + "CatCollapseAnimation.png", 11);
			imagesList.put("CatCollapse", maillerList);

			maillerList = loadStrip(STATICDIR + "CatSpinAnimation.png", 14);
			imagesList.put("CatSpinning", maillerList);

			mailler = getIm(STATICDIR + "CatHouse.png");
			maillerList = new ArrayList<BufferedImage>();
			maillerList.add(mailler);
			imagesList.put("CatHouse", maillerList);

			mailler = getIm(STATICDIR + "Canon.png");
			maillerList = new ArrayList<BufferedImage>();
			maillerList.add(mailler);
			imagesList.put("Cannon", maillerList);

			mailler = getIm(STATICDIR + "CloudPuff.png");
			maillerList = new ArrayList<BufferedImage>();
			maillerList.add(mailler);
			imagesList.put("CloudPuff", maillerList);

			mailler = getIm(STATICDIR + "Mirror.png");
			maillerList = new ArrayList<BufferedImage>();
			maillerList.add(mailler);
			imagesList.put("Mirror", maillerList);

			// int imWidth = (int) mailler.getWidth() / 3;
			// int height = mailler.getHeight();
			// int transparency = mailler.getColorModel().getTransparency();
			// System.out.println("Made it here.");
			// GraphicsConfiguration yots = null;
			// GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
			// yots = ge.getDefaultScreenDevice().getDefaultConfiguration();

			System.out.println("MAde it to part 2");
			// Graphics2D stripGC;
			// maillerList.add(yots.createCompatibleImage(imWidth, height, transparency));
			// stripGC = maillerList.get(0).createGraphics();

			System.out.println("Made it to part 3");
			// stripGC.drawImage(mailler, 0, 0, imWidth, height, imWidth * 1, 0, (imWidth +
			// imWidth), height, null);

			// stripGC.dispose();
			// System.out.println("Made it to part 4");
			// maillerList.add(mailler);
			// imagesList.put("CryingKitty", maillerList);
			/*
			 * Now we get the cat pieces.
			 */
			// mailler = getIm("CatFacePlant.png");
			// maillerList = new ArrayList<BufferedImage>();
			// imWidth = (int) mailler.getWidth() / 3;
			// height = mailler.getHeight();
			// transparency = mailler.getColorModel().getTransparency();
			// maillerList.add(yots.createCompatibleImage(imWidth, height, transparency));
			// stripGC = maillerList.get(0).createGraphics();
			// stripGC.drawImage(mailler,0, 0, imWidth, height, (imWidth * 0), 0, (imWidth *
			// 1) + 1, height, null);

			// maillerList.add(yots.createCompatibleImage(imWidth, height, transparency));
			// stripGC = maillerList.get(1).createGraphics();
			// stripGC.drawImage(mailler,0, 0, imWidth, height, (imWidth * 1) + 1, 0,
			// (imWidth * 2) + 0, height, null);

			// maillerList.add(yots.createCompatibleImage(imWidth, height, transparency));
			// stripGC = maillerList.get(2).createGraphics();
			// stripGC.drawImage(mailler,0, 0, imWidth, height, (imWidth * 2), 0, (imWidth *
			// 3) + 0, height, null);

			// stripGC.dispose();
			// imagesList.put("CatFacePlant", maillerList);
			// System.out.println("Put in catFacePlant.png");

		} catch (Exception e) {
			System.out.println("Something is... not right.");
		}

	}

	/*
	 * Loads a theme based on the string given to it.
	 */
	//public void loadContextData() {

		//BufferedImage item1 = getIm("KKFLBackGround.png");
		//ArrayList<BufferedImage> list = new ArrayList<BufferedImage>();
		//list.add(item1);
		//imagesList.put("Background", list);

		//item1 = getIm("HorizontalBoundaryBlockKKFL2.png");
		//list = new ArrayList<BufferedImage>();
		//list.add(item1);
		//item1 = getIm("VerticalBoundaryBlockKKFL2.png");
		//list.add(item1);
		//imagesList.put("BoundaryBlocks", list);
	//}

	private ArrayList<BufferedImage> loadStrip(String fileName, int numI) {

		GraphicsConfiguration yots = null;
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		yots = ge.getDefaultScreenDevice().getDefaultConfiguration();
		Graphics2D stripGC = null;

		BufferedImage tempImage;
		ArrayList<BufferedImage> animationList = new ArrayList<BufferedImage>();
		tempImage = getIm(fileName);
		int imWidth = (int) tempImage.getWidth() / numI;
		int height = tempImage.getHeight();
		int transparency = tempImage.getColorModel().getTransparency();

		for (int i = 0; i < numI; i++) {
			animationList.add(yots.createCompatibleImage(imWidth, height, transparency));
			stripGC = animationList.get(i).createGraphics();
			stripGC.drawImage(tempImage, 0, 0, imWidth, height, (imWidth * i), 0, (imWidth * (i + 1)), height, null);
		}
		stripGC.dispose();
		return animationList;

	}

	/**
	 * The getImageFromHash function returns a ArrayList<BufferedImage> for a given String key.
	 * This image must have been loaded in prior to use.
	 * @param get The String key used for image location
	 * @return The ArrayList of BufferedImages according to the get key. Null if the image cannot be found.
	 */
	public ArrayList<BufferedImage> getImageFromHash(String get) {
		return imagesList.get(get);
	}


}
