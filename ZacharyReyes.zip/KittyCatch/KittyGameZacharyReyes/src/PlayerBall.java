import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

/**
 * The PlayerBall class is a class that handles most of the collision detection
 * among elements in the game. It has a size constraint in that it MUST be a
 * square and the lengths of its sides must by divisible by four.
 * 
 * @author Zachary Reyes
 *
 */
public class PlayerBall extends BBMoveable {

	private Sensor rightSensor;
	private Sensor upSensor;
	private Sensor downSensor;
	private Sensor leftSensor;
	private Sensor upRightSensor;
	private Sensor upLeftSensor;
	private Sensor downLeftSensor;
	private Sensor downRightSensor;
	private int fourth;
	private double xFrictionalAdd;
	private double yFrictionalAdd;
	private boolean prevRightCollision = false;
	private boolean prevLeftCollision = false;
	private boolean prevUpCollision = false;
	private boolean prevDownCollision = false;
	private boolean prevUpRightCollision = false;
	private boolean prevUpLeftCollision = false;
	private boolean prevDownRightCollision = false;
	private boolean prevDownLeftCollision = false;
	private boolean isPointingRight;
	private int accelerationResist;
	private int constAccelerationY;
	private int constAccelerationX;
	private boolean isLaunched;
	private boolean isContact;
	private ToolBox hannity;
	// private BufferedImage yo;
	// private BufferedImage animation2;
	// private BufferedImage animation3;
	// private BufferedImage[] strip;
	private int imageNum;
	private int previousTick = 0;

	// Code for states of the gato.
	private final int BEGINNING = 0;
	private final int LAUNCHING = 1;
	private final int INAIR = 2;
	private final int SLIDING = 3;
	private final int ISSTOPPED = 4;
	private int currState;
	private int prevState;
	private ArrayList<BufferedImage> imageList;
	private boolean inCannon;

	/**
	 * @return the inCannon
	 */
	public boolean isInCannon() {
		return inCannon;
	}

	/**
	 * @param inCannon the inCannon to set
	 */
	public void setInCannon(boolean inCannon) {
		this.inCannon = inCannon;
	}

	/**
	 * 
	 * @param x
	 *            is the initial x position
	 * @param y
	 *            is the initial y position
	 * @param xs
	 *            is the width of the player
	 * @param ys
	 *            is the height of the player
	 * @param xV
	 *            is the initial x velocity of the player
	 * @param yV
	 *            is the initial y velocity of the player
	 * @param m
	 *            is the mass of the player character.
	 * 
	 *            The PlayerBall constructor creates a new PlayerBall object. The
	 *            PlayerBall object can be initialized with an initial x and y
	 *            velocity, as well as a mass value. The PlayerBall object also has
	 *            to have a x and y position and width and height value as well.
	 */
	public PlayerBall(int x, int y, int xs, int ys, int xV, int yV, int m, ToolBox james) {

		super(x, y, xs, ys, xV, yV, m);
		hannity = james;
		currState = 0;
		isLaunched = false;
		fourth = xs / 4;
		rightSensor = new Sensor(x, y, xs / 4, ys / 2);
		leftSensor = new Sensor(x, y, xs / 4, ys / 2);
		upSensor = new Sensor(x, y, xs / 2, ys / 4);
		downSensor = new Sensor(x, y, xs / 2, ys / 4);

		upRightSensor = new Sensor(x, y, xs / 4, ys / 4);
		upLeftSensor = new Sensor(x, y, xs / 4, ys / 4);
		downLeftSensor = new Sensor(x, y, xs / 4, ys / 4);
		downRightSensor = new Sensor(x, y, xs / 4, ys / 4);
		xFrictionalAdd = 0;
		yFrictionalAdd = 0;
		accelerationResist = 40;
		constAccelerationY = 0;
		constAccelerationX = 0;
		imageList = hannity.getImageFromHash("CatStanding"); 
		System.out.println(imageList == null);
		isPointingRight = true;
		isContact = false;
		// strip = new BufferedImage[4];
		// yo = ToolBox.getIm("./TestImageAnimation-1.png");
		// animation2 = ToolBox.getIm("./TestImageAnimation-2.png");
		// animation3 = ToolBox.getIm("./TestImageAnimation-3.png");
		// yo = ToolBox.getImageFromHash("CatFacePlant").get(0);
		// int i = 0;
		// for (i = 0; i < 15; i ++) {
		// strip[i] = ToolBox.getIm("./TestImageAnimation-1.png");
		// }
		// while (i < 30) {
		// strip[i] = ToolBox.getIm("./TestImageAnimation-2.png");
		// i = i + 1;
		// }
		// while (i < 45) {
		// strip[i] = ToolBox.getIm("./TestImageAnimation-3.png");
		// i = i + 1;
		// }
		// while (i < 60) {
		// strip[i] = ToolBox.getIm("./TestImageAnimation-2.png");
		// i = i + 1;
		// }
		// strip[0] = yo;
		// strip[1] = ToolBox.getImageFromHash("CatFacePlant").get(1);
		// strip[2] = ToolBox.getImageFromHash("CatFacePlant").get(2);
		// strip[3] = ToolBox.getIm("./TestImageAnimation-2.png");
		imageNum = 0;

	}

	/**
	 * @return the isContact
	 */
	public boolean isContact() {
		return isContact;
	}

	/**
	 * @param isContact the isContact to set
	 */
	public void setContact(boolean isContact) {
		this.isContact = isContact;
	}

	/**
	 * @return the upSensor
	 */
	public Sensor getUpSensor() {
		return upSensor;
	}

	/**
	 * @param upSensor
	 *            the upSensor to set
	 */
	public void setUpSensor(Sensor upSensor) {
		this.upSensor = upSensor;
	}

	/**
	 * @return the downSensor
	 */
	public Sensor getDownSensor() {
		return downSensor;
	}

	/**
	 * @param downSensor
	 *            the downSensor to set
	 */
	public void setDownSensor(Sensor downSensor) {
		this.downSensor = downSensor;
	}

	/**
	 * @return the leftSensor
	 */
	public Sensor getLeftSensor() {
		return leftSensor;
	}

	/**
	 * @param leftSensor
	 *            the leftSensor to set
	 */
	public void setLeftSensor(Sensor leftSensor) {
		this.leftSensor = leftSensor;
	}

	/**
	 * @return the upRightSensor
	 */
	public Sensor getUpRightSensor() {
		return upRightSensor;
	}

	/**
	 * @param upRightSensor
	 *            the upRightSensor to set
	 */
	public void setUpRightSensor(Sensor upRightSensor) {
		this.upRightSensor = upRightSensor;
	}

	/**
	 * @return the upLeftSensor
	 */
	public Sensor getUpLeftSensor() {
		return upLeftSensor;
	}

	/**
	 * @param upLeftSensor
	 *            the upLeftSensor to set
	 */
	public void setUpLeftSensor(Sensor upLeftSensor) {
		this.upLeftSensor = upLeftSensor;
	}

	/**
	 * @return the downLeftSensor
	 */
	public Sensor getDownLeftSensor() {
		return downLeftSensor;
	}

	/**
	 * @param downLeftSensor
	 *            the downLeftSensor to set
	 */
	public void setDownLeftSensor(Sensor downLeftSensor) {
		this.downLeftSensor = downLeftSensor;
	}

	/**
	 * @return the downRightSensor
	 */
	public Sensor getDownRightSensor() {
		return downRightSensor;
	}

	/**
	 * @param downRightSensor
	 *            the downRightSensor to set
	 */
	public void setDownRightSensor(Sensor downRightSensor) {
		this.downRightSensor = downRightSensor;
	}

	/**
	 * 
	 * @param gui
	 *            is the Graphics object to draw on the screen
	 * 
	 *            The draw method takes a Graphics object and draws the playable
	 *            character on the screen. It also draws a line that approximates
	 *            the net velocity of the player character. The default color for
	 *            the character's internals is green, and its outline is black.
	 */
	public void draw(Graphics gui, int ugh, int mx, int my) {

		gui.setColor(Color.RED);

		if (currState == BEGINNING) {
			gui.drawLine(this.getxPos() + (2 * fourth), this.getyPos() + (2 * fourth), mx, my);
		}

		if (this.isInCannon() == false) {
		if (imageList == null) {
			if (prevDownLeftCollision || prevDownRightCollision || prevUpRightCollision || prevUpLeftCollision) {
				gui.setColor(Color.MAGENTA);
			} else {
				gui.setColor(Color.GREEN);
			}
			gui.fillRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
			gui.setColor(Color.BLACK);
			gui.drawRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		} else {

			// This order may need to be adjusted for completeness.
			this.determineLoadNeed();
			this.determineState(this.getAccelerationX(), this.getAccelerationY());
			// this.determineLoadNeed();
			if (currState == LAUNCHING) {
				this.LaunchAnimationCompleted();
			}
			// determineIfNextAnimation(ugh);
			if (isPointingRight) {
				gui.drawImage(imageList.get(imageNum), this.getxPos(), this.getyPos(), this.getxSize(), this.getySize(),
						null);

				// gui.dr

			} else {
				gui.drawImage(imageList.get(imageNum), (this.getxPos() + this.getxSize()), this.getyPos(),
						(this.getxPos()), (this.getyPos() + this.getySize()), 0, 0, imageList.get(imageNum).getWidth(),
						imageList.get(imageNum).getHeight(), null);

			}
			determineIfNextAnimation(ugh);

		}
		}
		
		// drawAllSensors(gui);

	}

	private void determineIfNextAnimation(int jk) {
		if (previousTick != jk) {
			previousTick = jk;
			if (imageNum == imageList.size() - 1) {
				if (currState != LAUNCHING && currState != ISSTOPPED) {
					imageNum = 0;
				}
			} else {
				imageNum++;
			}
		}
	}

	private void drawAllSensors(Graphics g) {
		rightSensor.draw(g);
		leftSensor.draw(g);
		upSensor.draw(g);
		downSensor.draw(g);

		upLeftSensor.draw(g);
		upRightSensor.draw(g);
		downLeftSensor.draw(g);
		downRightSensor.draw(g);
	}

	private void setAllSensors() {
		int threeFourths = 3 * fourth;
		rightSensor.setxPos(this.getxPos() + threeFourths);
		rightSensor.setyPos(this.getyPos() + fourth);

		leftSensor.setxPos(this.getxPos());
		leftSensor.setyPos(this.getyPos() + fourth);

		upSensor.setxPos(this.getxPos() + fourth);
		upSensor.setyPos(this.getyPos());

		downSensor.setxPos(this.getxPos() + fourth);
		downSensor.setyPos(this.getyPos() + threeFourths);

		upLeftSensor.setxPos(this.getxPos());
		upLeftSensor.setyPos(this.getyPos());

		upRightSensor.setxPos(this.getxPos() + threeFourths);
		upRightSensor.setyPos(this.getyPos());

		downLeftSensor.setxPos(this.getxPos());
		downLeftSensor.setyPos(this.getyPos() + threeFourths);

		downRightSensor.setxPos(this.getxPos() + threeFourths);
		downRightSensor.setyPos(this.getyPos() + threeFourths);

	}

	/**
	 * @return the rightSensor
	 */
	public Sensor getRightSensor() {
		return rightSensor;
	}

	/**
	 * @param rightSensor
	 *            the rightSensor to set
	 */
	public void setRightSensor(Sensor rightSensor) {
		this.rightSensor = rightSensor;
	}

	/**
	 * 
	 * @param leftSense
	 *            is the left sensor collision boolean
	 * @param rightSense
	 *            is the right sensor collision boolean
	 * @param upSense
	 *            is the up sensor collision boolean
	 * @param downSense
	 *            is the down sensor collision boolean
	 * @param upRight
	 *            is the upper-right sensor collision boolean
	 * @param upLeft
	 *            is the upper-left sensor collision boolean
	 * @param downRight
	 *            is the down-right sensor collision boolean
	 * @param downLeft
	 *            is the down-left sensor collision boolean
	 * @param k
	 *            is the MazeObstacle that is allegedly collided with.
	 * 
	 *            The collisionDetectionSlow method calculates whether the player's
	 *            character has collided with a particular MazeObstacle. Depending
	 *            on the boolean inputs, the player character will react
	 *            accordingly. A lot of the logic is symmetric, so understanding how
	 *            one sensor works gives you an idea of how the whole system works.
	 */
	public void collisionDetectionSlow(boolean leftSense, boolean rightSense, boolean upSense, boolean downSense,
			boolean upRight, boolean upLeft, boolean downRight, boolean downLeft, MazeObstacle k) {
		// boolean upSense = upSensor.isIntersection();
		// boolean downSense = downSensor.isIntersection();
		// boolean rightSense = rightSensor.isIntersection();
		// boolean leftSense = leftSensor.isIntersection();
		double bounce = k.getBounciness();
		double axVelocity = Math.abs(this.getxVelocity());
		double ayVelocity = Math.abs(this.getyVelocity());

		// if (rightSense && !leftSense && !downLeft && !upLeft && (upRight ||
		// downRight)) {
		if (rightSense && !leftSense) {
			// System.out.println("Detected a right collision.");

			// if (!prevRightCollision) {
			// prevRightCollision = true;
			if (!prevRightCollision) {
				if (k.getFrictionalRemove() < axVelocity) {
					// prevRightCollision = true;
					this.setxVelocity(((this.getxVelocity() * -1) + k.getFrictionalRemove()) * (int) (4 * bounce));
					this.setAccelerationResist(this.getAccelerationResist() + k.getEnergyRestore());
				}
			}
			if (k.getFrictionalRemove() >= axVelocity && this.getAccelerationX() >= 0) {
				this.setxVelocity(0);
			}
			if (this.getxVelocity() == 0) {
				this.setyVelocity(translationalFrictionX(this.getyVelocity(), k));
			}

		}
		// if (prevRightCollision) {
		// System.out.println("No longer detecting unique collision.");
		// }
		// prevRightCollision = false;

		// if (leftSense && !rightSense && !upRight && !downRight && (upLeft ||
		// downLeft)) {
		if (leftSense && !rightSense) {
			// System.out.println("Detected a left collision.");
			// System.out.println("left collision: " + prevLeftCollision);
			if (!prevLeftCollision) {
				if (k.getFrictionalRemove() < axVelocity) {
					this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) * (int) (4 * bounce));
					this.setAccelerationResist(this.getAccelerationResist() + k.getEnergyRestore());
				}
			}
			if (k.getFrictionalRemove() >= axVelocity && this.getAccelerationX() <= 0) {
				this.setxVelocity(0);
			}
			if (this.getxVelocity() == 0) {
				this.setyVelocity(translationalFrictionX(this.getyVelocity(), k));
			}
		} // Do left collision Stuff
			// if (upSense && !downSense && !downRight && !downLeft && (upRight || upLeft))
			// {
		if (upSense && !downSense) {
			if (!prevUpCollision) {
				// System.out.println("Detected an up collision.");
				if (k.getFrictionalRemove() < ayVelocity) {
					this.setyVelocity(((this.getyVelocity() * -1) - k.getFrictionalRemove()) * (int) (4 * bounce));
					this.setAccelerationResist(this.getAccelerationResist() + k.getEnergyRestore());
				}
			}
			if (k.getFrictionalRemove() >= ayVelocity && this.getAccelerationY() <= 0) {
				this.setyVelocity(0);
			}
			if (this.getyVelocity() == 0) {
				this.setxVelocity(translationalFrictionX(this.getxVelocity(), k));
			}
			// this.setyVelocity(this.getyVelocity() * -1);
		}
		// Do up Collision stuff
		// if (downSense && !upSense && !upRight && !upLeft && (downRight || downLeft))
		// {
		if (downSense && !upSense) {
			// System.out.println("Detected a down collision.");
			// if (!prevDownCollision) {
			// prevDownCollision = true;
			if (!prevDownCollision) {
				if (k.getFrictionalRemove() < ayVelocity) {
					// System.out.println(((this.getyVelocity() * -1) + k.getFrictionalRemove()) *
					// (int) (4 * bounce));
					this.setyVelocity(((this.getyVelocity() * -1) + k.getFrictionalRemove()) * (int) (4 * bounce ));
					this.setAccelerationResist(this.getAccelerationResist() + k.getEnergyRestore());
					// this.setyVelocity(this.getyVelocity() * -1);
				}
			}
			if (k.getFrictionalRemove() >= ayVelocity && this.getAccelerationY() >= 0) {
				// System.out.println("Setting velocity to zero.");
				this.setyVelocity(0);
			}
			if (this.getyVelocity() == 0) {
				this.setxVelocity(translationalFrictionX(this.getxVelocity(), k));
			}
			// Do down collision stuff
			// }
		}
		// if (upRight && !leftSense && !rightSense && !downSense && !upSense &&
		// !downRight && !upLeft && !downLeft) {
		// // System.out.println("Up right sense");
		// if (!prevUpRightCollision) {

		// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
		// axVelocity) {
		// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
		// (int) (4 * bounce));
		// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
		// (int) (4 * bounce));
		// this.setAccelerationResist(this.getAccelerationResist() +
		// k.getEnergyRestore());
		// System.out.println("Detected and shifting");
		// }
		// }
		// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
		// axVelocity
		// && (this.getAccelerationY() <= 0 || this.getAccelerationX() >= 0)) {
		// this.setxVelocity(0);
		// this.setyVelocity(0);
		// System.out.println("Stopping");
		// }

		// }
		// if (!upRight && !leftSense && !rightSense && !downSense && !upSense &&
		// !downRight && upLeft && !downLeft) {
		// if (!prevUpLeftCollision) {
		// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
		// axVelocity) {

		// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
		// (int) (4 * bounce));
		// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
		// (int) (4 * bounce));
		// this.setAccelerationResist(this.getAccelerationResist() +
		// k.getEnergyRestore());
		// }
		// }
		// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
		// axVelocity
		// && (this.getAccelerationY() <= 0 || this.getAccelerationX() <= 0)) {
		// this.setxVelocity(0);
		// this.setyVelocity(0);
		// // System.out.println("Stopping");
		// }

		// }
		// if (!upRight && !leftSense && !rightSense && !downSense && !upSense &&
		// downRight && !upLeft && !downLeft) {
		// if (!prevDownRightCollision) {
		// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
		// axVelocity) {

		// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
		// (int) (4 * bounce));
		// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
		// (int) (4 * bounce));
		// this.setAccelerationResist(this.getAccelerationResist() +
		// k.getEnergyRestore());
		// }
		// }
		// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
		// axVelocity
		// && (this.getAccelerationY() >= 0 || this.getAccelerationX() >= 0)) {
		// this.setxVelocity(0);
		// this.setyVelocity(0);
		// System.out.println("Stopping");
		// }
		// }
		// if (!upRight && !leftSense && !rightSense && !downSense && !upSense &&
		// !downRight && !upLeft && downLeft) {
		// if (!prevDownLeftCollision) {
		// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
		// axVelocity) {

		// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
		// (int) (4 * bounce));
		// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
		// (int) (4 * bounce));
		// this.setAccelerationResist(this.getAccelerationResist() +
		// k.getEnergyRestore());
		// }
		// }
		// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
		// axVelocity
		// && (this.getAccelerationY() >= 0 || this.getAccelerationX() >= 0)) {
		// this.setxVelocity(0);
		// this.setyVelocity(0);
		// System.out.println("Stopping");
		// }

		// }

	}

	private boolean isSliding(int gx, int gy) {
		// Check for different gravity cases.
		// For left gravity:
		if (gx != 0 && this.getxVelocity() == 0 && this.getyVelocity() != 0) {
			return true;
		} else if (gy != 0 && this.getxVelocity() != 0 && this.getyVelocity() == 1) {
			return true;
		} else {
			return false;
		}
	}

	private void determineState(int gX, int gY) {

		prevState = currState;

		// NEW VERSION:
		if (this.getxVelocity() == 0 && this.getyVelocity() == 0) {
			currState = BEGINNING;
		} else if (isLaunched == false && (this.getxVelocity() != 0 || this.getyVelocity() != 0)) {
			currState = LAUNCHING;
		} else if (isSliding(gX, gY) && this.isContact) {
			currState = SLIDING;
		} else if (this.getxVelocity() == 0 && this.getyVelocity() == 1) {
			currState = ISSTOPPED;
		} else {
			currState = INAIR;
		}
		/*
		 * } First check to see if player has moved.
		 */
		// if (this.getxVelocity() == 0 && this.getyVelocity() == 0) {
		// Check to see if the cat has been launched

		// If the cat hasn't been launched yet.
		// if (!isLaunched && currState == BEGINNING) {
		// currState = BEGINNING;
		// } else {
		// Do this if the cat HAS been launched already and the cat has slowed to a
		// complete stop.
		// currState = ISSTOPPED;
		// }
		// } else {
		// if (!isLaunched) {
		// currState = LAUNCHING;
		// } else if (isSliding(gX, gY)) {
		// currState = SLIDING;
		// } else {
		// currState = INAIR;
		// }
		// }
		/*
		 * Check to see if the object is launching.
		 */

	}

	private void LaunchAnimationCompleted() {
		if (imageNum == imageList.size() - 1) {
			isLaunched = true;
		}
	}

	private void determineLoadNeed() {
		if (prevState != currState) {
			this.loadImageArray();
			imageNum = 0;
		}
	}

	private void loadImageArray() {

		switch (currState) {
		case BEGINNING:
			imageList = hannity.getImageFromHash("CatStanding");
			break;
		case LAUNCHING:
			imageList = hannity.getImageFromHash("CatJumping");
			break;
		case INAIR:
			imageList = hannity.getImageFromHash("CatSpinning");
			break;
		case SLIDING:
			imageList = hannity.getImageFromHash("CatFacePlant");
			break;
		case ISSTOPPED:
			imageList = hannity.getImageFromHash("CatCollapse");
			break;
		default:

		}

	}

	/**
	 * @return the prevUpRightCollision
	 */
	public boolean isPrevUpRightCollision() {
		return prevUpRightCollision;
	}

	/**
	 * @param prevUpRightCollision
	 *            the prevUpRightCollision to set
	 */
	public void setPrevUpRightCollision(boolean prevUpRightCollision) {
		this.prevUpRightCollision = prevUpRightCollision;
	}

	/**
	 * @return the prevUpLeftCollision
	 */
	public boolean isPrevUpLeftCollision() {
		return prevUpLeftCollision;
	}

	/**
	 * @param prevUpLeftCollision
	 *            the prevUpLeftCollision to set
	 */
	public void setPrevUpLeftCollision(boolean prevUpLeftCollision) {
		this.prevUpLeftCollision = prevUpLeftCollision;
	}

	/**
	 * @return the prevDownRightCollision
	 */
	public boolean isPrevDownRightCollision() {
		return prevDownRightCollision;
	}

	/**
	 * @param prevDownRightCollision
	 *            the prevDownRightCollision to set
	 */
	public void setPrevDownRightCollision(boolean prevDownRightCollision) {
		this.prevDownRightCollision = prevDownRightCollision;
	}

	/**
	 * @return the prevDownLeftCollision
	 */
	public boolean isPrevDownLeftCollision() {
		return prevDownLeftCollision;
	}

	/**
	 * @param prevDownLeftCollision
	 *            the prevDownLeftCollision to set
	 */
	public void setPrevDownLeftCollision(boolean prevDownLeftCollision) {
		this.prevDownLeftCollision = prevDownLeftCollision;
	}

	/**
	 * @return the prevRightCollision
	 */
	public boolean isPrevRightCollision() {
		return prevRightCollision;
	}

	/**
	 * @param prevRightCollision
	 *            the prevRightCollision to set
	 */
	public void setPrevRightCollision(boolean prevRightCollision) {
		this.prevRightCollision = prevRightCollision;
	}

	/**
	 * @return the prevLeftCollision
	 */
	public boolean isPrevLeftCollision() {
		return prevLeftCollision;
	}

	/**
	 * @param prevLeftCollision
	 *            the prevLeftCollision to set
	 */
	public void setPrevLeftCollision(boolean prevLeftCollision) {
		this.prevLeftCollision = prevLeftCollision;
	}

	/**
	 * @return the prevUpCollision
	 */
	public boolean isPrevUpCollision() {
		return prevUpCollision;
	}

	/**
	 * @param prevUpCollision
	 *            the prevUpCollision to set
	 */
	public void setPrevUpCollision(boolean prevUpCollision) {
		this.prevUpCollision = prevUpCollision;
	}

	/**
	 * @return the prevDownCollision
	 */
	public boolean isPrevDownCollision() {
		return prevDownCollision;
	}

	/**
	 * @param prevDownCollision
	 *            the prevDownCollision to set
	 */
	public void setPrevDownCollision(boolean prevDownCollision) {
		this.prevDownCollision = prevDownCollision;
	}


	/**
	 * The translationFrictionX method simply applies the frictional removal quantity of the MazeObstacle
	 * on the PlayerBall object. It is assumed that the PlayerBall object and MazeObstacle o object have collided whenever this method is called.
	 * 
	 * @param currentVelocityParallel The current velocity 
	 * @param o the MazeObstacle to get the frictional force from.
	 * @return The modified velocity
	 */
	public double translationalFrictionX(double currentVelocityParallel, MazeObstacle o) {
		boolean isLeft;
		// int frictional = o.getFrictionalRemove();
		int frictional = 0;
		xFrictionalAdd = xFrictionalAdd + (0.05 * o.getFrictionalRemove());

		if (xFrictionalAdd >= 1) {
			frictional = (int) (xFrictionalAdd / 1);
			xFrictionalAdd = 0;
		}
		if (currentVelocityParallel < 0) {
			isLeft = true;
		} else {
			isLeft = false;
		}
		double aCVP = Math.abs(currentVelocityParallel);
		if (frictional < aCVP) {
			aCVP = aCVP - frictional;
		} else {
			aCVP = 0;
		}
		if (isLeft) {
			currentVelocityParallel = aCVP * -1;
		} else {
			currentVelocityParallel = aCVP;
		}
		return currentVelocityParallel;

	}

	/**
	 * 
	 * @param x
	 *            is the x position of the click
	 * @param y
	 *            is the y position of the click
	 * 
	 *            The calculateInitialMouseClick method sets the x and y velocity of
	 *            the playable character based on the input parameters.
	 * 
	 */
	public void calculateInitialMouseClick(int x, int y) {
		double magnitude = 0.0;
		int xDist = Math.abs(x - this.getxPos());
		int yDist = Math.abs(y - this.getyPos());
		double magSquared = Math.pow(xDist, 2.0) + Math.pow(yDist, 2.0);
		magnitude = Math.pow(magSquared, 0.5);
		double cos = xDist / magnitude;
		double sin = yDist / magnitude;
		double magXSpeed =  (int) (cos *  this.getMAXSPEEDX());
		double magYSpeed =  (int) (sin * this.getMAXSPEEDX());
		// int magXSpeed = (int) (cos * 5);
		// int magYSpeed = (int) (sin * 5);
		// System.out.println("cos: " + cos);
		// System.out.println("sin: " + sin);
		// System.out.println("maxXSpeed: " + magXSpeed);
		// System.out.println("maxYSpeed: " + magYSpeed);
		// System.out.println("x: " + x);
		// System.out.println("y: " + y);
		if (y < this.getyPos()) {
			magYSpeed = magYSpeed * -1;
		}
		if (x < this.getxPos()) {
			magXSpeed = magXSpeed * -1;
		}
		currState = LAUNCHING;
		this.setxVelocity(magXSpeed);
		this.setyVelocity(magYSpeed);

	}


	private void determineAccelerationY() {
		if (Math.abs(this.getConstAccelerationY()) > 0) {
			// System.out.println(this.getAccelerationResist());
			if (this.getAccelerationResist() > 0) {

				this.setAccelerationY(0);
				this.setAccelerationResist(this.getAccelerationResist() - 1);
			} else {
				this.setAccelerationY(this.getConstAccelerationY());
			}
		}
		// System.out.println(getAccelerationResist());
	}

	private void determineAccelerationX() {
		if (Math.abs(this.getConstAccelerationX()) > 0) {
			if (this.getAccelerationResist() > 0) {
				this.setAccelerationX(0);
				this.setAccelerationResist(this.getAccelerationResist() - 1);
			} else {
				this.setAccelerationX(this.getConstAccelerationX());
			}
		}
	}

	/**
	 * @return the accelerationResist
	 */
	public int getAccelerationResist() {
		return accelerationResist;
	}

	/**
	 * @param accelerationResist
	 *            the accelerationResist to set
	 */
	public void setAccelerationResist(int accelerationResist) {

		if (accelerationResist <= 30) {
			this.accelerationResist = accelerationResist;
		} else {
			this.accelerationResist = 30;
		}
	}

	/**
	 * @return the constAccelerationY
	 */
	public int getConstAccelerationY() {
		return constAccelerationY;
	}

	/**
	 * @param constAccelerationY
	 *            the constAccelerationY to set
	 */
	public void setConstAccelerationY(int constAccelerationY) {
		this.constAccelerationY = constAccelerationY;
	}

	/**
	 * @return the constAccelerationX
	 */
	public int getConstAccelerationX() {
		return constAccelerationX;
	}

	/**
	 * @param constAccelerationX
	 *            the constAccelerationX to set
	 */
	public void setConstAccelerationX(int constAccelerationX) {
		this.constAccelerationX = constAccelerationX;
	}

	/**
	 * 
	 * @param xLow
	 *            is the lower x position to check
	 * @param yLow
	 *            is the lower y position to check
	 * @param xHigh
	 *            is the higher x position to check
	 * @param yHigh
	 *            is the higher y position to check
	 * @return True if intersecting with the coordinates, false if not.
	 * 
	 *         The intersecting method takes the four coordinates of a square and
	 *         determines whether or not the player character is intersecting within
	 *         those four points.
	 */
	public boolean intersecting(int xLow, int yLow, int xHigh, int yHigh) {

		boolean inter = false;

		
		inter = (xLow > (this.getxPos() + this.getxSize()) || this.getxPos() > xHigh || (this.getyPos() + this.getySize()) < yLow || this.getyPos() > yHigh );
		// check lower points.
		//if (inBetween(this.getxPos(), xLow, xHigh) && inBetween(this.getyPos(), yLow, yHigh)) {
		//	inter = true;
		//}
		//if (inBetween(this.getxPos() + this.getxSize(), xLow, xHigh) && inBetween(this.getyPos(), yLow, yHigh)) {
		//	inter = true;
		//}
		//if (inBetween(this.getxPos(), xLow, xHigh) && inBetween(this.getyPos() + this.getySize(), yLow, yHigh)) {
		///	inter = true;
		//}
		//if (inBetween(this.getxPos() + this.getxSize(), xLow, xHigh)
		//		&& inBetween(this.getyPos() + this.getySize(), yLow, yHigh)) {
		//	inter = true;
		//}
		// System.out.println(tLowX);
		return !inter;

	}

	/**
	 * @return the currState
	 */
	public int getCurrState() {
		return currState;
	}

	/**
	 * @param currState the currState to set
	 */
	public void setCurrState(int currState) {
		this.currState = currState;
	}

	private boolean inBetween(int pConsidered, int pLow, int pHi) {

		if (pConsidered >= pLow && pConsidered <= pHi) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * The updateNextInterval method simply calls the methods to update the player's
	 * position, acceleration, and velocity, in that order.
	 */
	public void updateNextInterval() {
		this.updateXpos();
		this.updateYpos();
		this.determineAccelerationY();
		this.determineAccelerationX();
		this.updateVelocityX();
		this.updateVelocityY();
		this.determineDirection();
		setAllSensors();
	}

	private void determineDirection() {
		if (this.getxVelocity() > 0) {
			isPointingRight = true;
		} else if (this.getxVelocity() < 0) {
			isPointingRight = false;
		} else {

		}
	}

	/**
	 * The resetAllValues method stops all movement of the player's character.
	 */
	public void resetAllValues() {

		currState = BEGINNING;
		isPointingRight = true;
		isLaunched = false;

		this.setAccelerationX(0);
		this.setAccelerationY(0);
		this.setxVelocity(0);
		this.setyVelocity(0);
	}
}
