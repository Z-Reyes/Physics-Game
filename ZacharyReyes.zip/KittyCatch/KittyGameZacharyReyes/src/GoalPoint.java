import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
 * 
 * The GoalPoint class is the class used for our goal in the game. I just needs to be stationary and act as an icon.
 * @author Zachary Reyes
 *
 */
public class GoalPoint extends BBElement {
	
	private BufferedImage icon;
	
	/**
	 * 
	 * @param x is the initial x position of the GoalPoint
	 * @param y is the initial y position of the GoalPoint
	 * @param x1 is the width of the GoalPoint
	 * @param y1 is the height of the GoalPoint
	 * 
	 * The GoalPoint constructor creates a new GoalPoint object.
	 * 		
	 */
	public GoalPoint (int x, int y, int x1, int y1, ToolBox james) {
		super(x, y, x1, y1);
		icon = james.getImageFromHash("CatHouse").get(0);
	}
	
	/**
	 * 
	 * @param gui is the Graphics object to be used.
	 * 
	 * The draw method draws the GoalPoint object at its x and y position. The default color for the internals of the goal is yellow, and the outline default color is black.
	 */
	public void draw(Graphics gui) {
		
		if (icon == null) {
		gui.setColor(Color.YELLOW);
		gui.fillRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		gui.setColor(Color.BLACK);
		gui.drawRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		} else {
			gui.drawImage(icon, this.getxPos(), this.getyPos(), this.getxSize(), this.getySize(), null);
		}
	}

}
