import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.*;
import java.util.*;

/**
 * The SpringObstacle class is used to create SpringObstacle objects. These
 * objects are used to jump players across gaps and distances.
 * 
 * @author Zachary Reyes
 *
 */
public class SpringObstacle extends MazeObstacle {

	/**
	 * 
	 * @param x1
	 *            is the initial x position of the SpringObstacle
	 * @param y2
	 *            is the initial y position of the SpringObstacle
	 * @param sx
	 *            is the size of the width of the SpringObstacle
	 * @param sy
	 *            is the size of the length of the SpringObstacle
	 * 
	 *            The SpringObstacle constructor creates a SpringObstacle object.
	 *            When the object is created, the bounciness, frictionalRemove, and
	 *            energy restore values are automatically assigned.
	 */
	public SpringObstacle(int x1, int y2, int sx, int sy, ToolBox james) {
		super(x1, y2, sx, sy);
		this.setBounciness(0.75);
		this.setFrictionalRemove(0);
		this.setEnergyRestore(40);
		this.setMyImage(james.getImageFromHash("SpringSprite").get(0));
	}

	/**
	 * @param gui
	 *            is the Graphics class to be used.
	 * 
	 *            The draw method draws a SpringObstacle. The default color is
	 *            orange for the internals of the obstacle, and red is the default
	 *            color for the outline of the obstacle.
	 */
	public void draw(Graphics gui) {

		//ArrayList<BufferedImage> temp = ToolBox.getImageFromHash("SpringSprite");

		if (this.getMyImage() != null) {
			gui.drawImage(this.getMyImage(), this.getxPos(), this.getyPos(), this.getxSize(), this.getySize(), null);
			//gui.setColor(Color.GREEN);
			//gui.drawString(Double.toString(this.getBounciness()), this.getxSize(), this.getySize());
			//super.draw(gui);
		} else {

			gui.setColor(Color.ORANGE);
			gui.fillRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
			gui.setColor(Color.RED);
			gui.drawRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		
		}
		
	}
	


}
