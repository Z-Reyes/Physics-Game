import java.awt.Color;
import java.awt.Graphics;

/**
 * The ContextCursor class is simply used for the mouse cursor of our game. It provides some context on what the player can click on given its position and the game's mode.
 * @author Zachary Reyes
 *
 */
public class ContextCursor extends BBElement {
	
	private final int LOWERX = 45;
	private final int HIGHX =  1525;
	private final int LOWY = 55;
	private final int HIGHY = 1030;
	private final int TOOLBOXXLOW = 1526;
	private final int TOOLBOXXHIGH = 1920;
	private final int TOOLBOXYLOW = 55;
	private final int TOOLBOXYHIGH = 1030;

	private int radius;
	private int tempRadius;
	private int pulse = 10;
	
	/**
	 * 
	 * @param r is the default radius size of the contextCursor.
	 * 
	 * The contextCursor constructor creates a new contextCursor with a radius as determined by the input parameter.
	 */
	public ContextCursor(int r) {
		super(0,0,0,0);
		radius = r;
		tempRadius = radius;
		
	}
	
	private void cycleRadius() {
		if (tempRadius <= radius + pulse) {
			tempRadius = tempRadius + 1;
		} else {
			tempRadius = radius;
		}
	}
	
	private boolean intersectingPlay(int x, int y) {
		
		if (x <= HIGHX && x >= LOWERX && y <= HIGHY && y >= LOWY) {
			return true;
		} else {
			return false;
		}
		
	}
	private boolean intersectingTool(int x, int y) {
		if (x <= TOOLBOXXHIGH && x >= TOOLBOXXLOW && y <= TOOLBOXYHIGH && y >= TOOLBOXYLOW) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 
	 * @param gui is the Graphics object to be used for drawing
	 * @param pick is a boolean describing the state of the game.
	 * 
	 * The draw method for the contextCursor draws a contextCursor at the location of the mouse pointer.
	 * The color used for drawing the contextCursor depends largely on the state of the game and the location of the pointer.
	 * If the game is in "pick up" mode, the cursor turns white.
	 * If the cursor is in the ToolBox area, the cursor turns blue.
	 * If the cursor is in the play area, the cursor turns orange.
	 * If otherwise, the cursor turns gray.
	 */
	public void draw(Graphics gui, boolean pick) {
		int tempX = (this.getxPos() - tempRadius/2);
		int tempY = (this.getyPos() - tempRadius/2);
		
		if (pick) {
			gui.setColor(Color.WHITE);
		} else if (intersectingPlay(this.getxPos() - radius/2, this.getyPos() - radius/2)) {
		gui.setColor(Color.ORANGE);
		} else if (intersectingTool(this.getxPos() - radius/2, this.getyPos() - radius/2)){
			gui.setColor(Color.BLUE);
		}  else {
			gui.setColor(Color.GRAY);
		}
		gui.fillOval(tempX,tempY, tempRadius, tempRadius);
		this.cycleRadius();
		
	}

}
