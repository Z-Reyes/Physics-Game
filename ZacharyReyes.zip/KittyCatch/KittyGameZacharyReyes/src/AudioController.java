import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import javax.sound.sampled.*;
/**
 * The AudioController class is the class used to control our Audio loading and playback.
 * @author Zachary Reyes
 *
 */
public class AudioController {

	private static AudioInputStream stream;
	// private static AudioInputStream stream2;
	private static AudioFormat format = null;
	private static SourceDataLine line = null;
	private HashMap<String, Clip> sounds;
	private static Clip catSoundEffect;
	private Clip currBack;
	private Clip currSFX;
	private Clip jumps;
	private boolean contact;
	private final String DIRECTORY = "/SOUNDS/";
	// private static Clip getGoodie;
	private static Clip levelCompleteSound;


	/**
	 * The constructor for our AudioController class.
	 */
	public AudioController() {
		sounds = new HashMap<String, Clip>();
		// currBack = new Clip();
		// currSFX = new Clip();
		contact = false;
		loadAllSounds();
	}

	private void loadAllSounds() {
		// Nothing fancy, literally walks through all of the sounds.
		try {
			Clip clips = AudioSystem.getClip();
			stream = AudioSystem.getAudioInputStream(AudioController.class.getResource(DIRECTORY + "CFire.wav"));
			clips.open(stream);
			sounds.put("CFire", clips);

			clips = AudioSystem.getClip();
			stream = AudioSystem.getAudioInputStream(AudioController.class.getResource(DIRECTORY + "jump.wav"));
			clips.open(stream);
			sounds.put("jump", clips);
			jumps = clips;

			clips = AudioSystem.getClip();
			stream = AudioSystem.getAudioInputStream(AudioController.class.getResource(DIRECTORY + "MBreak.wav"));
			clips.open(stream);
			sounds.put("MBreak", clips);

			clips = AudioSystem.getClip();
			stream = AudioSystem.getAudioInputStream(AudioController.class.getResource(DIRECTORY + "meow.wav"));
			clips.open(stream);
			sounds.put("meow", clips);

			clips = AudioSystem.getClip();
			stream = AudioSystem.getAudioInputStream(AudioController.class.getResource(DIRECTORY + "powerUp.wav"));
			clips.open(stream);
			sounds.put("powerUp", clips);

			clips = AudioSystem.getClip();
			stream = AudioSystem.getAudioInputStream(AudioController.class.getResource(DIRECTORY + "HLL.wav"));
			clips.open(stream);
			sounds.put("HLL", clips);

			clips = AudioSystem.getClip();
			stream = AudioSystem.getAudioInputStream(AudioController.class.getResource(DIRECTORY + "KKFL.wav"));
			clips.open(stream);
			sounds.put("KKFL", clips);
			
			clips = AudioSystem.getClip();
			stream = AudioSystem.getAudioInputStream(AudioController.class.getResource(DIRECTORY + "ML.wav"));
			clips.open(stream);
			sounds.put("ML", clips);

		} catch (LineUnavailableException e) {
			System.out.println("Line is unavailable.");
		} catch (UnsupportedAudioFileException e) {
			System.out.println(e.getMessage());
			System.exit(0);
		} catch (IOException e) {
			System.out.println(e.getMessage());
			System.exit(0);
		}

	}

//	public static void createInput() {
//		try {

//			levelCompleteSound = AudioSystem.getClip();
//			stream = AudioSystem.getAudioInputStream(new File("benNo.wav"));
//			levelCompleteSound.open(stream);
//			catSoundEffect = AudioSystem.getClip();
//			stream = AudioSystem.getAudioInputStream(new File("HLL.wav"));
//			catSoundEffect.open(stream);
//			stream = AudioSystem.getAudioInputStream(new File("test.wav"));
//			format = stream.getFormat();

//			if ((format.getEncoding() == AudioFormat.Encoding.ULAW)
//					|| (format.getEncoding() == AudioFormat.Encoding.ALAW)) {
//				AudioFormat newFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, format.getSampleRate(),
//						format.getSampleSizeInBits() * 2, format.getChannels(), format.getFrameSize() * 2,
//						format.getFrameRate(), true);
//				stream = AudioSystem.getAudioInputStream(newFormat, stream);
//				System.out.println("Converted Audio format: " + newFormat);
//				format = newFormat;
//			}
//		} catch (LineUnavailableException e) {
//			System.out.println("Line is unavailable.");
//		} catch (UnsupportedAudioFileException e) {
//			System.out.println(e.getMessage());
//			System.exit(0);
//		} catch (IOException e) {
//			System.out.println(e.getMessage());
//			System.exit(0);
//		}
//	}

	//public static void createOutput() {
	//	try {
			// gather information for line creation
	//		DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
	//		if (!AudioSystem.isLineSupported(info)) {
	//			System.out.println("Line does not support: " + format);
	//			System.exit(0);
	//		}
			// get a line of the required format
	//		line = (SourceDataLine) AudioSystem.getLine(info);
	//		line.open(format);
	//	} catch (Exception e) {
	//		System.out.println(e.getMessage());
	//		System.exit(0);
	//	}
	//}

	//public static void play()
	/*
	 * Read the sound file in chunks of bytes into buffer, and pass them on through
	 * the SourceDataLine
	 */
	//{

	//	int numRead = 0;
	//	byte[] buffer = new byte[line.getBufferSize()];

	//	line.start();
		// read and play chunks of the audio
	//	try {
	//		int offset;
	//		while ((numRead = stream.read(buffer, 0, buffer.length)) >= 0) {
				// System.out.println("read: " + numRead);
	//			offset = 0;
	//			while (offset < numRead)
	//				offset += line.write(buffer, offset, numRead - offset);
	//		}
	//	} catch (IOException e) {
	//		System.out.println(e.getMessage());
	//	}

		// wait until all data is played, then close the line
		// System.out.println("drained start");
	//	line.drain();
		// System.out.println("drained end");
	//	line.stop();
	//	line.close();
	//} // end of play()

	/**
	 * The playClip method plays a clip for a given String key
	 * @param t the String key for the audioClip to play.
	 */
	public void playClip(String t) {
		try {
			if (currSFX != null) {

				currSFX.setFramePosition(0);
				currSFX.stop();
				// currSFX.flush();
			}
			currSFX = sounds.get(t);
			currSFX.start();
			// currSFX.stop();
			// currSFX.setFramePosition(0);

		} catch (Exception e) {
			System.out.println("What in tarnation? " + e);
		}
	}
/**
 * The playJump method plays the jump sound effect for every unique PlayerBall - MazeObstacle collision.
 * Unique meaning that the PlayerBall has just hit a MazeObstacle.
 * @param c a boolean used to determine if the PlayerBall was previously in contact with a MazeObstacle
 */
	public void playJump(boolean c) {

		if (c == false) {
			contact = true;
			jumps.setFramePosition(0);
			jumps.start();
		}

	}

	/**
	 * The playBackground method plays the given string as a background sound. It will loop until the game ends or a new playBackground method is called.
	 * @param t The String key for the audio hashtable
	 */
	public void playBackground(String t) {

		try {
			if (currBack != sounds.get(t)) {
				if (currBack != null) {
					currBack.setFramePosition(0);
					currBack.stop();
				}
				currBack = sounds.get(t);
				currBack.loop(Clip.LOOP_CONTINUOUSLY);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
