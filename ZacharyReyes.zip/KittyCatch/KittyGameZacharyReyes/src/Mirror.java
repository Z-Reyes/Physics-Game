import java.awt.Color;
import java.awt.Graphics;
/**
 * The Mirror class is used for the Mirror game object. When the player hits this object, the whole world flips about the y axis.
 * @author Zachary Reyes
 *
 */
public class Mirror extends MazeObstacle {
	

	/**
	 * 
	 * @param x1 the x position of the mirror
	 * @param y1 the y position of the mirror
	 * @param sx the width of the mirror
	 * @param sy the height of the mirror
	 * @param james the ToolBox object used for image gathering for the mirror
	 */
	public Mirror(int x1, int y1, int sx, int sy, ToolBox james) {
		super(x1, y1, sx, sy);
		this.setActivated(false);
		this.setDead(false);
		this.setMyImage(james.getImageFromHash("Mirror").get(0));
	}

	/**
	 * The collision method determines what happens to the PlayerBall object if it has collided with this object.
	 * @param j This is the PlayerBall to be operated upon.
	 * @param leftSense This is the PlayerBall's left sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param rightSense This is the PlayerBall's right sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param upSense This is the PlayerBall's up sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param downSense This is the PlayerBall's down sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param upRightSense This is the PlayerBall's upRight sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param upLeftSense This is the PlayerBall's upLeft sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param downRightSense This is the PlayerBall's downRight sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param downLeftSense This is the PlayerBall's downLeft sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param joe This is the AudioController used to determine which sound to play.
	 * @param ben This is the contextCursor, which gives the position of the mouse cursor.
	 * 
	 * In this case, the collision method will place the PlayerBall into the Mirror, shattering it and flipping the world.
	 */
	public void collision(PlayerBall p, boolean leftSense, boolean rightSense, boolean upSense, boolean downSense,
			boolean upRight, boolean upLeft, boolean downRight, boolean downLeft, AudioController j, ContextCursor ben) {

		if (this.isActivated() == false && isIntersecting(p.getxPos(), p.getyPos(), p.getxPos() + p.getxSize(), p.getyPos() + p.getySize()) && p.isInCannon() == false && p.getCurrState() != 0) {
			this.setActivated(true);
			j.playClip("MBreak");
		}
	}

	/**
	 * The draw method simply draws the Mirror object.
	 */
	public void draw(Graphics gui) {

		if (this.isActivated() == false) {
			
			if (this.getMyImage() == null) {
			// if (bb == null) {
			gui.setColor(Color.CYAN);
			gui.fillRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
			gui.setColor(Color.BLACK);
			gui.drawRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
			// gui.drawString(Double.toString(this.getBounciness()), this.getxSize(),
			// this.getySize());
			// } else {
			// gui.drawImage(bb, this.getxPos(), this.getyPos(), this.getxSize(),
			// this.getySize(), null);
			// }
			} else {
				gui.drawImage(this.getMyImage(), this.getxPos(), this.getyPos(), this.getxSize(), this.getySize(), null);
			}
		}
	}

}
