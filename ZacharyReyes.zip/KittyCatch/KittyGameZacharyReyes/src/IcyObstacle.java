import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
/**
 * The IcyObstacle class is a subclass of MazeObstacle. It is pretty much just a MazeObstacle but just with different frictional and bounciness values.
 * 
 * @author Zachary Reyes
 *
 */

public class IcyObstacle extends MazeObstacle{
	private BufferedImage scaled;

	/**
	 * 
	 * @param x1
	 *            is the initial x position of the IcyObstacle
	 * @param y2
	 *            is the initial y position of the IcyObstacle
	 * @param sx
	 *            is the size of the width of the IcyObstacle
	 * @param sy
	 *            is the size of the length of the IcyObstacle
	 * 
	 *            The IcyObstacle constructor creates a IcyObstacle object.
	 *            When the object is created, the bounciness, frictionalRemove, and
	 *            energy restore values are automatically assigned.
	 */
	public IcyObstacle (int x1, int y2, int sx, int sy, ToolBox james) {
		super (x1, y2, sx, sy);
		this.setBounciness(0.25);
		this.setFrictionalRemove(1);
		this.setEnergyRestore(0);
		this.setMyImage(james.getImageFromHash("IceSprite").get(0));
		//int widthRatio = (this.getxSize() / 400);
		//int heightRatio = (this.getySize() / 20);
		//int newWidth = (this.getMyImage().getWidth() * widthRatio);
		//int newHeight = (this.getMyImage().getHeight() * heightRatio);
		try {
		//scaled = new BufferedImage(800, 100, this.getMyImage().getType());
		//this.setMyImage(scaled);
		} catch (Exception e) {
			System.out.println("Oh no");
		}
		
	}
	/**
	 * @param gui
	 *            is the Graphics class to be used.
	 * 
	 *            The draw method draws a IcyObstacle. The default color is
	 *            cyan for the internals of the obstacle, and blue is the default
	 *            color for the outline of the obstacle.
	 */
	public void draw(Graphics gui) {
		
		if (this.getMyImage() == null) {
		gui.setColor(Color.CYAN);
		gui.fillRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		gui.setColor(Color.BLUE);
		gui.drawRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		} else {
			//this.getMyImage()
			//if (scaled != null) {
			//	gui.drawImage(scaled, this.getxPos(), this.getyPos(), null);
			//} else {
			
			gui.drawImage(this.getMyImage(), this.getxPos(), this.getyPos(), this.getxSize(),this.getySize(), null);
			//}
		}
	}
	
	/**
	 * The collision method determines what happens to the PlayerBall object if it has collided with this object.
	 * @param j This is the PlayerBall to be operated upon.
	 * @param leftSense This is the PlayerBall's left sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param rightSense This is the PlayerBall's right sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param upSense This is the PlayerBall's up sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param downSense This is the PlayerBall's down sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param upRightSense This is the PlayerBall's upRight sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param upLeftSense This is the PlayerBall's upLeft sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param downRightSense This is the PlayerBall's downRight sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param downLeftSense This is the PlayerBall's downLeft sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param joe This is the AudioController used to determine which sound to play.
	 * @param ben This is the contextCursor, which gives the position of the mouse cursor.
	 * 
	 * In this case, the collision method will place the PlayerBall into the ice block, letting it slip across the block.
	 */
	public void collision(PlayerBall p, boolean leftSense, boolean rightSense, boolean upSense, boolean downSense,
			boolean upRight, boolean upLeft, boolean downRight, boolean downLeft, AudioController joe, ContextCursor ben) {
		
		// boolean upSense = upSensor.isIntersection();
		// boolean downSense = downSensor.isIntersection();
		// boolean rightSense = rightSensor.isIntersection();
		// boolean leftSense = leftSensor.isIntersection();
		double bounce = this.getBounciness();
		//System.out.println(this.getBounciness());
	//	System.out.println(bounce);
		double axVelocity = Math.abs(p.getxVelocity());
		double ayVelocity = Math.abs(p.getyVelocity());

		// if (rightSense && !leftSense && !downLeft && !upLeft && (upRight ||
		// downRight)) {
		if (rightSense && !leftSense && p.getxVelocity() >= 0) {
			// System.out.println("Detected a right collision.");

			// if (!prevRightCollision) {
			// prevRightCollision = true;
			//if (!p.isPrevRightCollision()) {
			//	if (this.getFrictionalRemove() < axVelocity) {
					// prevRightCollision = true;
				//	p.setxVelocity(((p.getxVelocity() * -1) + this.getFrictionalRemove()) * (int) (4 * bounce));
				//	p.setAccelerationResist(p.getAccelerationResist() + this.getEnergyRestore());
				//}
			//}
			//if (this.getFrictionalRemove() >= axVelocity && p.getAccelerationX() >= 0) {
			//	p.setxVelocity(0);
			//}
			//if (p.getxVelocity() == 0) {
			//	p.setyVelocity(p.translationalFrictionX(p.getyVelocity(), this));
			//}
			if (p.getAccelerationX() >= 0) {
			p.setxVelocity(0);
			} else {
				p.setxVelocity(((p.getxVelocity() * -1) + this.getFrictionalRemove()) * (int) (4 * bounce));
			}

		}
		// if (prevRightCollision) {
		// System.out.println("No longer detecting unique collision.");
		// }
		// prevRightCollision = false;

		// if (leftSense && !rightSense && !upRight && !downRight && (upLeft ||
		// downLeft)) {
		if (leftSense && !rightSense && p.getxVelocity() <= 0) {
			// System.out.println("Detected a left collision.");
			// System.out.println("left collision: " + prevLeftCollision);
			//if (!p.isPrevLeftCollision()) {
			//	if (this.getFrictionalRemove() < axVelocity) {
			//		p.setxVelocity(((p.getxVelocity() * -1) - this.getFrictionalRemove()) * (int) (4 * bounce));
			//		p.setAccelerationResist(p.getAccelerationResist() + this.getEnergyRestore());
			//	}
			//}
			//if (this.getFrictionalRemove() >= axVelocity && p.getAccelerationX() <= 0) {
			//	p.setxVelocity(0);
			//}
			//if (this.getxVelocity() == 0) {
			//	p.setyVelocity(p.translationalFrictionX(p.getyVelocity(), this));
			//}
			if (p.getAccelerationX() <= 0) {
			p.setxVelocity(0);
			} else {
				p.setxVelocity(((p.getxVelocity() * -1) - this.getFrictionalRemove()) * (int) (4 * bounce));
			}
		} // Do left collision Stuff
			// if (upSense && !downSense && !downRight && !downLeft && (upRight || upLeft))
			// {
		if (upSense && !downSense && p.getyVelocity() <= 0) {
			//if (!p.isPrevUpCollision()) {
				// System.out.println("Detected an up collision.");
			//	if (this.getFrictionalRemove() < ayVelocity) {
			//		p.setyVelocity(((p.getyVelocity() * -1) - this.getFrictionalRemove()) * (int) (4 * bounce));
			//		p.setAccelerationResist(p.getAccelerationResist() + this.getEnergyRestore());
			//	}
			//}
			//if (this.getFrictionalRemove() >= ayVelocity && p.getAccelerationY() <= 0) {
			//	p.setyVelocity(0);
			//}
			//if (p.getyVelocity() == 0) {
			//	p.setxVelocity(p.translationalFrictionX(p.getxVelocity(), this));
			//}
			// this.setyVelocity(this.getyVelocity() * -1);
			if (p.getAccelerationY() <= 0) {
			p.setyVelocity(0);
			} else {
				p.setyVelocity(((p.getyVelocity() * -1) + this.getFrictionalRemove()) * (int) (4 * bounce));
			}
		}
		// Do up Collision stuff
		// if (downSense && !upSense && !upRight && !upLeft && (downRight || downLeft))
		// {
		if (downSense && !upSense && p.getyVelocity() >= 0) {
			// System.out.println("Detected a down collision.");
			// if (!prevDownCollision) {
			// prevDownCollision = true;
			//if (!p.isPrevDownCollision()) {
			//	if (this.getFrictionalRemove() < ayVelocity) {
					// System.out.println(((this.getyVelocity() * -1) + k.getFrictionalRemove()) *
					// (int) (4 * bounce));
			//		p.setyVelocity(((p.getyVelocity() * -1) + this.getFrictionalRemove()) * (int) (4 * bounce));
			//		p.setAccelerationResist(p.getAccelerationResist() + this.getEnergyRestore());
					// this.setyVelocity(this.getyVelocity() * -1);
			//	}
			//}
			//if (this.getFrictionalRemove() >= ayVelocity && p.getAccelerationY() >= 0) {
				// System.out.println("Setting velocity to zero.");
			//	p.setyVelocity(0);
			//}
			//if (p.getyVelocity() == 0) {
			//	p.setxVelocity(p.translationalFrictionX(p.getxVelocity(), this));
			//}
			// Do down collision stuff
			// }
			if (p.getAccelerationY() >= 0) {
			p.setyVelocity(0);
			} else {
				p.setyVelocity(((p.getyVelocity() * -1) + this.getFrictionalRemove()) * (int) (4 * bounce));
			}
			//p.updateVelocityY();
		}
		// if (upRight && !leftSense && !rightSense && !downSense && !upSense &&
		// !downRight && !upLeft && !downLeft) {
		// // System.out.println("Up right sense");
		// if (!prevUpRightCollision) {

		// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
		// axVelocity) {
		// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
		// (int) (4 * bounce));
		// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
		// (int) (4 * bounce));
		// this.setAccelerationResist(this.getAccelerationResist() +
		// k.getEnergyRestore());
		// System.out.println("Detected and shifting");
		// }
		// }
		// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
		// axVelocity
		// && (this.getAccelerationY() <= 0 || this.getAccelerationX() >= 0)) {
		// this.setxVelocity(0);
		// this.setyVelocity(0);
		// System.out.println("Stopping");
		// }

		// }
		// if (!upRight && !leftSense && !rightSense && !downSense && !upSense &&
		// !downRight && upLeft && !downLeft) {
		// if (!prevUpLeftCollision) {
		// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
		// axVelocity) {

		// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
		// (int) (4 * bounce));
		// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
		// (int) (4 * bounce));
		// this.setAccelerationResist(this.getAccelerationResist() +
		// k.getEnergyRestore());
		// }
		// }
		// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
		// axVelocity
		// && (this.getAccelerationY() <= 0 || this.getAccelerationX() <= 0)) {
		// this.setxVelocity(0);
		// this.setyVelocity(0);
		// // System.out.println("Stopping");
		// }

		// }
		// if (!upRight && !leftSense && !rightSense && !downSense && !upSense &&
		// downRight && !upLeft && !downLeft) {
		// if (!prevDownRightCollision) {
		// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
		// axVelocity) {

		// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
		// (int) (4 * bounce));
		// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
		// (int) (4 * bounce));
		// this.setAccelerationResist(this.getAccelerationResist() +
		// k.getEnergyRestore());
		// }
		// }
		// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
		// axVelocity
		// && (this.getAccelerationY() >= 0 || this.getAccelerationX() >= 0)) {
		// this.setxVelocity(0);
		// this.setyVelocity(0);
		// System.out.println("Stopping");
		// }
		// }
		// if (!upRight && !leftSense && !rightSense && !downSense && !upSense &&
		// !downRight && !upLeft && downLeft) {
		// if (!prevDownLeftCollision) {
		// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
		// axVelocity) {

		// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
		// (int) (4 * bounce));
		// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
		// (int) (4 * bounce));
		// this.setAccelerationResist(this.getAccelerationResist() +
		// k.getEnergyRestore());
		// }
		// }
		// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
		// axVelocity
		// && (this.getAccelerationY() >= 0 || this.getAccelerationX() >= 0)) {
		// this.setxVelocity(0);
		// this.setyVelocity(0);
		// System.out.println("Stopping");
		// }

		// }


		
	}
}
