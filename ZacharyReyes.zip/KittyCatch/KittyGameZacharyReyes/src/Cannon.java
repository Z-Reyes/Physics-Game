import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
/**
 * The Cannon class is a game object used to shoot the PlayerBall across the stage.
 * @author Zachary Reyes
 *
 */
public class Cannon extends MazeObstacle {

	//private int playerYAccel;
	//private int playerXAccel;
	private BufferedImage puff;
	//private double spin;
	private double spin;
	private double xDist;
	private double yDist;
	private float puffFade;
	private boolean isLaunched;
	private int puffPos;

	/**
	 * 
	 * @param x1 the starting x position for the Cannon object.
	 * @param y1 the starting y position for the Cannon object.
	 * @param sx the width size of the Cannon object.
	 * @param sy the height size of the Cannon object.
	 * @param james The ToolBox object used to get the initial images that represent the Cannon.
	 */
	public Cannon(int x1, int y1, int sx, int sy, ToolBox james) {
		super(x1, y1, sx, sy);
		//playerYAccel = 0;
		//playerXAccel = 0;
		this.setMyImage(james.getImageFromHash("Cannon").get(0));
		puff = james.getImageFromHash("CloudPuff").get(0);
		spin = 0;
		xDist = 0;
		yDist = 0;
		isLaunched = false;
		puffFade = 1;
		puffPos = 0;
	}

	/**
	 * The draw method draws the Cannon object (as well as the fading cloud puff) onto the screen.
	 */
	public void draw(Graphics gui) {

		// if (bb == null) 
		//spin += 0.1;
		Graphics2D item = (Graphics2D) gui;
		//item.ro
		//System.out.println(spin);
		AffineTransform origAT = item.getTransform();
		AffineTransform newAT = new AffineTransform();
		newAT.rotate(spin, this.getxPos() + (this.getxSize()/2), this.getyPos() + (this.getySize()/2));
		if (this.getMyImage() == null) {
		gui.setColor(Color.DARK_GRAY);
		gui.fillRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		gui.setColor(Color.BLACK);
		gui.drawRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		// gui.drawString(Double.toString(this.getBounciness()), this.getxSize(),
		// this.getySize());
		// } else {
		// gui.drawImage(bb, this.getxPos(), this.getyPos(), this.getxSize(),
		// this.getySize(), null);
		// }
		} else {
			item.transform(newAT);
			item.drawImage(this.getMyImage(), this.getxPos(), this.getyPos(), this.getxSize(), this.getySize(), null);
			Composite ch = item.getComposite();
			if (isLaunched == true) {
				
				item.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, puffFade));
				item.drawImage(puff, this.getxPos() + (5 *this.getxSize()/6) + puffPos, this.getyPos() + this.getySize()/6, null);
				puffFade -= 0.04;
				puffPos += 1;
				if (puffFade <= 0) {
					puffFade = 1;
					isLaunched = false;
					puffPos = 0;
				}
	
			}
			item.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1));
			item.setTransform(origAT);
		}
	}

	private void determineDirection(double x, double y, int sx, int sy) {
		double centerSx = (x + (sx/2));
		double centerSy = (y + (sy/2));
		
		double centerHx = (this.getxPos() + (this.getxSize()/2));
		double centerHy = (this.getyPos() + (this.getySize()/2));
	
		xDist = Math.abs(centerSx - centerHx);
		yDist = Math.abs(centerSy - centerHy);
		
		spin = (Math.atan(yDist/xDist));
		//System.out.println(spin);
		//System.out.println(spin);
		if (centerSx >= centerHx && centerSy <= centerHy) {
			spin = ((2 * Math.PI) - spin);
		} else if (centerSx <= centerHx && centerSy <= centerHy) {
			spin = (((Math.PI)) + spin);
		} else if (centerSx <= centerHx && centerSy >= centerHy) {
			spin = ((Math.PI) - spin);
		}

		
	}
	/**
	 * The collision method determines what happens to the PlayerBall object if it has collided with this object.
	 * @param j This is the PlayerBall to be operated upon.
	 * @param leftSense This is the PlayerBall's left sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param rightSense This is the PlayerBall's right sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param upSense This is the PlayerBall's up sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param downSense This is the PlayerBall's down sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param upRightSense This is the PlayerBall's upRight sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param upLeftSense This is the PlayerBall's upLeft sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param downRightSense This is the PlayerBall's downRight sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param downLeftSense This is the PlayerBall's downLeft sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param joe This is the AudioController used to determine which sound to play.
	 * @param ben This is the contextCursor, which gives the position of the mouse cursor.
	 * 
	 * In this case, the collision method will place the PlayerBall into the cannon, allowing it to be shot out.
	 */
	public void collision(PlayerBall j, boolean leftSense, boolean rightSense, boolean upSense, boolean downSense,
			boolean upRight, boolean upLeft, boolean downRight, boolean downLeft, AudioController joe, ContextCursor ben) {
			
			if (isIntersecting(j.getxPos(), j.getyPos(), j.getxPos() + j.getxSize(), j.getyPos() + j.getySize())) {
				determineDirection (ben.getxPos(), ben.getyPos(), ben.getxSize(), ben.getySize());

			// put the player in the cannon.
				if (j.isInCannon() == false && j.getCurrState() != 0) {
				
				//System.out.println("RunningCannonWork");
				int diffx = (this.getxSize() - j.getxSize()) / 2;
				int diffy = (this.getySize() - j.getySize()) / 2;
				j.setInCannon(true);
				j.setxPos(this.getxPos() + diffx);
				j.setyPos(this.getyPos() + diffy);
				j.setConstAccelerationX(0);
				j.setConstAccelerationY(0);
				j.resetAllValues();
				this.setActivated(true);
				}

			} else  if (this.isActivated() == true){
				if (j.isInCannon() == true) {
					//Launch Cloud.
					isLaunched = true;
					
				}
				this.setActivated(false);
				j.setInCannon(false);
			}
	}
}
