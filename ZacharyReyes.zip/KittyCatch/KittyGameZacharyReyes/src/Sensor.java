import java.awt.Color;
import java.awt.Graphics;

/**
 * The Sensor class is used to create our sensor objects. These objects are used for sensing collisions between the player and the Maze Obstacles.
 * @author Zachary Reyes
 *
 */
public class Sensor extends BBElement {
	private boolean intersection = false;
	private int lowX;
	private int hiX;
	
	private int lowY;
	private int hiY;
	
	/**
	 * 
	 * @param x1 is the initial x position of the Sensor
	 * @param y1 is the initial y position of the Sensor
	 * @param xs is the width of the Sensor
	 * @param ys is the height of the sensor
	 * 
	 * The Sensor class is a class used to determine whether a collision has occurred between the player character and some obstacle element.
	 * In this project, 8 of them are used in order to adjust the dot's velocity and acceleration.
	 */
	public Sensor (int x1, int y1, int xs, int ys) {
		super(x1, y1, xs, ys);
	}
	
	/**
	 * 
	 * @param gui is the Graphics object to be used to draw
	 * 		For debugging purposes. This draw method is used to highlight to the developer when the sensor has collided with an object. 
	 */
	public void draw( Graphics gui) {

		//intersection = true;
		if (intersection == true) {
			gui.setColor(Color.MAGENTA);
		} else {
		gui.setColor(Color.YELLOW);
		}
		gui.fillRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
	}
	
	private void setHiLowRange() {
		lowX = this.getxPos();
		hiX = this.getxPos() + this.getxSize();
		lowY = this.getyPos();
		hiY = this.getyPos() + this.getySize();
	}
	
	private boolean intersect(MazeObstacle target) {
		boolean inter = false;
		int tLowX = target.getxPos();
		int thiX = tLowX + target.getxSize();
		
		int tLowY = target.getyPos();
		int thiY = tLowY + target.getySize();
		
		inter = (tLowX > (this.getxPos() + this.getxSize()) || this.getxPos() > thiX || (this.getyPos() + this.getySize()) < tLowY || this.getyPos() > thiY );
		//check lower points.
	//	if (inBetween(lowX, tLowX, thiX) && inBetween(lowY, tLowY, thiY)) {
	//		inter = true;
	//	}
	//	if (inBetween(hiX, tLowX, thiX) && inBetween(lowY, tLowY, thiY)) {
	//		inter = true;
	//	}
	//	if (inBetween(lowX, tLowX, thiX) && inBetween(hiY, tLowY, thiY)) {
		//	inter = true;
		//}
		//if (inBetween(hiX, tLowX, thiX) && inBetween(hiY, tLowY, thiY)) {
		//	inter = true;
		//}
		//System.out.println(tLowX);
		return !inter;
	}
	/**
	 * @return the intersection
	 */
	public boolean isIntersection() {
		return intersection;
	}

	/**
	 * @param intersection the intersection to set
	 */
	public void setIntersection(boolean intersection) {
		this.intersection = intersection;
	}

	/**
	 * 
	 * @param tar is the MazeObstacle that is being checked for collision
	 * 
	 * 	The calculateIntersect method takes a MazeObstacle object and calls the methods used to calculate whether or not the MazeObstacle has collided with that sensor.
	 */
	public void calculateIntersect(MazeObstacle tar) {
		setHiLowRange();
		intersection = intersect(tar);
	}
	private boolean inBetween(int pConsidered, int pLow, int pHi) {
		
		if (pConsidered >= pLow && pConsidered <= pHi) {
			return true;
		} else {
			return false;
		}
	}
}
