import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
 * The MazeObstacle class is used to create our MazeObstacle objects. These objects act as obstacles for the player.
 * @author Zachary Reyes
 *
 */
public class MazeObstacle extends BBElement {
	
	private boolean isActivated;
	private boolean isDead;

	private double bounciness;
	private int frictionalRemove;
	private int energyRestore;
	//private BufferedImage bb;

	/**
	 * 
	 * @param x1
	 *            is the x position of the MazeObstacle
	 * @param y2
	 *            is the y position of the MazeObstacle
	 * @param sx
	 *            is the width of the MazeObstacle
	 * @param sy
	 *            is the height of the MazeObstacle
	 * 
	 *            The MazeObstacle constructor creates a new MazeObstacle object.
	 *            This new MazeObstacle object will have a default bounciness of
	 *            0.25, a frictional remove of 3, and an energy restor of 0.
	 */
	public MazeObstacle(int x1, int y2, int sx, int sy) {
		super(x1, y2, sx, sy);
		bounciness = .25;
		frictionalRemove = 3;
		energyRestore = 0;
		//this.setMyImage(ToolBox.getBoundaryBlock(this));
	}
	/**
	 * 
	 * @param x1 is the x position of the MazeObstacle
	 * @param y2 is the y position of the MazeObstacle
	 * @param sx is the width of the MazeObstacle
	 * @param sy is the height of the MazeObstacle
	 * @param james is the ToolBox object that we pull the MazeObstacle image from.
	 */
	public MazeObstacle(int x1, int y2, int sx, int sy, ToolBox james) {
		super(x1, y2, sx, sy);
		bounciness = .25;
		frictionalRemove = 3;
		energyRestore = 0;
		this.setMyImage(james.getBoundaryBlock(this));
		//bounciness = b;
		//frictionalRemove = fr;
		//energyRestore = e;
		//if (this.getxSize() > this.getySize()) {
		//bb = ToolBox.getImageFromHash("BoundaryBlocks").get(0);
		//} else {
		//	bb = ToolBox.getImageFromHash("BoundaryBlocks").get(1);
		//}
	}
	/**
	 * The collision method determines what happens to the PlayerBall object if it has collided with this object.
	 * @param j This is the PlayerBall to be operated upon.
	 * @param leftSense This is the PlayerBall's left sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param rightSense This is the PlayerBall's right sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param upSense This is the PlayerBall's up sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param downSense This is the PlayerBall's down sensor boolean. If collided, it will be true. Else, it will be false.
	 * @param upRightSense This is the PlayerBall's upRight sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param upLeftSense This is the PlayerBall's upLeft sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param downRightSense This is the PlayerBall's downRight sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param downLeftSense This is the PlayerBall's downLeft sensor boolean. If collided, it will be true. Else, it will be false. Unused
	 * @param joe This is the AudioController used to determine which sound to play.
	 * @param ben This is the contextCursor, which gives the position of the mouse cursor.
	 * 
	 * In this case, the collision method will place the PlayerBall into a wall, bouncing it.
	 * This method is also used for bouncing the PlayerBall on the spring.
	 */
	public void collision(PlayerBall p, boolean leftSense, boolean rightSense, boolean upSense, boolean downSense,
			boolean upRight, boolean upLeft, boolean downRight, boolean downLeft, AudioController j, ContextCursor ben) {
		
		// boolean upSense = upSensor.isIntersection();
				// boolean downSense = downSensor.isIntersection();
				// boolean rightSense = rightSensor.isIntersection();
				// boolean leftSense = leftSensor.isIntersection();
				double bounce = this.getBounciness();
				//System.out.println(this.getBounciness());
			//	System.out.println(bounce);
				double axVelocity = Math.abs(p.getxVelocity());
				double ayVelocity = Math.abs(p.getyVelocity());

				// if (rightSense && !leftSense && !downLeft && !upLeft && (upRight ||
				// downRight)) {
				if (rightSense && !leftSense && p.getxVelocity() >= 0) {
					// System.out.println("Detected a right collision.");

					// if (!prevRightCollision) {
					// prevRightCollision = true;
					if (!p.isPrevRightCollision()) {
						if (this.getFrictionalRemove() < axVelocity) {
							// prevRightCollision = true;
							p.setxVelocity(((p.getxVelocity() * -1) + this.getFrictionalRemove()) * (int) (4 * bounce));
							p.setAccelerationResist(p.getAccelerationResist() + this.getEnergyRestore());
						}
					}
					if (this.getFrictionalRemove() >= axVelocity && p.getAccelerationX() >= 0) {
						p.setxVelocity(0);
					}
					if (p.getxVelocity() == 0) {
						p.setyVelocity(p.translationalFrictionX(p.getyVelocity(), this));
					}

				}
				// if (prevRightCollision) {
				// System.out.println("No longer detecting unique collision.");
				// }
				// prevRightCollision = false;

				// if (leftSense && !rightSense && !upRight && !downRight && (upLeft ||
				// downLeft)) {
				if (leftSense && !rightSense && p.getxVelocity() <= 0) {
					// System.out.println("Detected a left collision.");
					// System.out.println("left collision: " + prevLeftCollision);
					if (!p.isPrevLeftCollision()) {
						if (this.getFrictionalRemove() < axVelocity) {
							p.setxVelocity(((p.getxVelocity() * -1) - this.getFrictionalRemove()) * (int) (4 * bounce));
							p.setAccelerationResist(p.getAccelerationResist() + this.getEnergyRestore());
						}
					}
					if (this.getFrictionalRemove() >= axVelocity && p.getAccelerationX() <= 0) {
						p.setxVelocity(0);
					}
					if (this.getxVelocity() == 0) {
						p.setyVelocity(p.translationalFrictionX(p.getyVelocity(), this));
					}
				} // Do left collision Stuff
					// if (upSense && !downSense && !downRight && !downLeft && (upRight || upLeft))
					// {
				if (upSense && !downSense && p.getyVelocity() <= 0) {
					if (!p.isPrevUpCollision()) {
						// System.out.println("Detected an up collision.");
						if (this.getFrictionalRemove() < ayVelocity) {
							p.setyVelocity(((p.getyVelocity() * -1) - this.getFrictionalRemove()) * (int) (4 * bounce));
							p.setAccelerationResist(p.getAccelerationResist() + this.getEnergyRestore());
						}
					}
					if (this.getFrictionalRemove() >= ayVelocity && p.getAccelerationY() <= 0) {
						p.setyVelocity(0);
					}
					if (p.getyVelocity() == 0) {
						p.setxVelocity(p.translationalFrictionX(p.getxVelocity(), this));
					}
					// this.setyVelocity(this.getyVelocity() * -1);
				}
				// Do up Collision stuff
				// if (downSense && !upSense && !upRight && !upLeft && (downRight || downLeft))
				// {
				if (downSense && !upSense && p.getyVelocity() >= 0) {
					// System.out.println("Detected a down collision.");
					// if (!prevDownCollision) {
					// prevDownCollision = true;
					if (!p.isPrevDownCollision()) {
						if (this.getFrictionalRemove() < ayVelocity) {
							// System.out.println(((this.getyVelocity() * -1) + k.getFrictionalRemove()) *
							// (int) (4 * bounce));
							p.setyVelocity(((p.getyVelocity() * -1) + this.getFrictionalRemove()) * (int) (4 * bounce));
							p.setAccelerationResist(p.getAccelerationResist() + this.getEnergyRestore());
							// this.setyVelocity(this.getyVelocity() * -1);
						}
					}
					if (this.getFrictionalRemove() >= ayVelocity && p.getAccelerationY() >= 0) {
						// System.out.println("Setting velocity to zero.");
						p.setyVelocity(0);
					}
					if (p.getyVelocity() == 0) {
						p.setxVelocity(p.translationalFrictionX(p.getxVelocity(), this));
					}
					boolean isHit = (downSense || upSense || leftSense || rightSense);
					if (isHit) {
						j.playJump(p.isContact());
						p.setContact(true);
					}
					
					// Do down collision stuff
					// }
				}
				// if (upRight && !leftSense && !rightSense && !downSense && !upSense &&
				// !downRight && !upLeft && !downLeft) {
				// // System.out.println("Up right sense");
				// if (!prevUpRightCollision) {

				// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
				// axVelocity) {
				// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
				// (int) (4 * bounce));
				// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
				// (int) (4 * bounce));
				// this.setAccelerationResist(this.getAccelerationResist() +
				// k.getEnergyRestore());
				// System.out.println("Detected and shifting");
				// }
				// }
				// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
				// axVelocity
				// && (this.getAccelerationY() <= 0 || this.getAccelerationX() >= 0)) {
				// this.setxVelocity(0);
				// this.setyVelocity(0);
				// System.out.println("Stopping");
				// }

				// }
				// if (!upRight && !leftSense && !rightSense && !downSense && !upSense &&
				// !downRight && upLeft && !downLeft) {
				// if (!prevUpLeftCollision) {
				// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
				// axVelocity) {

				// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
				// (int) (4 * bounce));
				// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
				// (int) (4 * bounce));
				// this.setAccelerationResist(this.getAccelerationResist() +
				// k.getEnergyRestore());
				// }
				// }
				// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
				// axVelocity
				// && (this.getAccelerationY() <= 0 || this.getAccelerationX() <= 0)) {
				// this.setxVelocity(0);
				// this.setyVelocity(0);
				// // System.out.println("Stopping");
				// }

				// }
				// if (!upRight && !leftSense && !rightSense && !downSense && !upSense &&
				// downRight && !upLeft && !downLeft) {
				// if (!prevDownRightCollision) {
				// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
				// axVelocity) {

				// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
				// (int) (4 * bounce));
				// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
				// (int) (4 * bounce));
				// this.setAccelerationResist(this.getAccelerationResist() +
				// k.getEnergyRestore());
				// }
				// }
				// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
				// axVelocity
				// && (this.getAccelerationY() >= 0 || this.getAccelerationX() >= 0)) {
				// this.setxVelocity(0);
				// this.setyVelocity(0);
				// System.out.println("Stopping");
				// }
				// }
				// if (!upRight && !leftSense && !rightSense && !downSense && !upSense &&
				// !downRight && !upLeft && downLeft) {
				// if (!prevDownLeftCollision) {
				// if (k.getFrictionalRemove() < ayVelocity || k.getFrictionalRemove() <
				// axVelocity) {

				// this.setyVelocity((this.getyVelocity() * -1) + k.getFrictionalRemove() *
				// (int) (4 * bounce));
				// this.setxVelocity(((this.getxVelocity() * -1) - k.getFrictionalRemove()) *
				// (int) (4 * bounce));
				// this.setAccelerationResist(this.getAccelerationResist() +
				// k.getEnergyRestore());
				// }
				// }
				// if (k.getFrictionalRemove() >= ayVelocity && k.getFrictionalRemove() >=
				// axVelocity
				// && (this.getAccelerationY() >= 0 || this.getAccelerationX() >= 0)) {
				// this.setxVelocity(0);
				// this.setyVelocity(0);
				// System.out.println("Stopping");
				// }

				// }
		
	}

	/**
	 * @return the energyRestore
	 */
	public int getEnergyRestore() {
		return energyRestore;
	}

	/**
	 * @param energyRestore
	 *            the energyRestore to set
	 */
	public void setEnergyRestore(int energyRestore) {
		this.energyRestore = energyRestore;
	}

	/**
	 * @return the frictionalRemove
	 */
	public int getFrictionalRemove() {
		return frictionalRemove;
	}

	/**
	 * @param frictionalRemove
	 *            the frictionalRemove to set
	 */
	public void setFrictionalRemove(int frictionalRemove) {
		this.frictionalRemove = frictionalRemove;
	}

	/**
	 * @return the bounciness
	 */
	public double getBounciness() {
		return bounciness;
	}

	/**
	 * @param bounciness
	 *            the bounciness to set
	 */
	public void setBounciness(double bounciness) {
		this.bounciness = bounciness;
	}

	/**
	 * 
	 * @param gui
	 *            is the Graphics object to be used for drawing
	 * 
	 *            The draw method draws a representation of the Maze Obstacle on the
	 *            screen. The default color of the Maze Obstacle internals is black,
	 *            and the outline of the obstacle is dark gray.
	 *
	 */
	public void draw(Graphics gui) {
		
		if (this.getMyImage() == null) {
		gui.setColor(Color.PINK);
		gui.fillRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		gui.setColor(Color.MAGENTA);
		gui.drawRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		//gui.drawString(Double.toString(this.getBounciness()), this.getxSize(), this.getySize());
		} else {
			gui.drawImage(this.getMyImage(), this.getxPos(), this.getyPos(), this.getxSize(), this.getySize(), null);
		}
	}

	/**
	 * 
	 * @param x
	 *            is the x position of the point being considered.
	 * @param y
	 *            is the y position of the point being considered.
	 * @return true if the MazeObstacle's intersect, otherwise return false.
	 * 
	 *         The isIntersecting method is a method that determines if two
	 *         MazeObstacles are intersecting. Put in the x and y position you want
	 *         to consider, and the method will return whether it found it to be
	 *         true or not.
	 */
	public boolean isIntersecting(int x, int y, int xHigh, int yHigh) {
		//if (x <= this.getxPos() + this.getxSize() && x >= this.getxPos() && y <= this.getyPos() + this.getySize()
		//		&& y >= this.getyPos()) {
		//	return true;
		//} else {
		//	return false;
		///}
		if  (x > (this.getxPos() + this.getxSize()) || this.getxPos() > xHigh || (this.getyPos() + this.getySize()) < y || this.getyPos() > yHigh ) {
			return false;
		} else {
			return true;
		}
	}
	/**
	 * @return the isActivated
	 */
	public boolean isActivated() {
		return isActivated;
	}

	/**
	 * @param isActivated the isActivated to set
	 */
	public void setActivated(boolean isActivated) {
		this.isActivated = isActivated;
	}

	/**
	 * @return the isDead
	 */
	public boolean isDead() {
		return isDead;
	}

	/**
	 * @param isDead the isDead to set
	 */
	public void setDead(boolean isDead) {
		this.isDead = isDead;
	}
}
