
/**
 * The BBMoveable class is a subclass of BBElement. It contains some basic values used for movement in the game.
 * @author Zachary Reyes
 *
 */
public class BBMoveable extends BBElement {
	

	private int xMomentum;
	private int yMomentum;

	private int mass;
	private int forceX;
	private int forceY;

	private int accelerationX;
	private int accelerationY;
	private double velocityxTemp;
	private double velocityyTemp;

	private int energyX;
	private int energyY;

	/**
	 * 
	 * @param x1 is the initial x position of the Moveable
	 * @param y1 is the initial y position of the Moveable
	 * @param siX is the width of the Moveable
	 * @param siY is the height of the Moveable
	 * @param ivX is the initial x velocity of the Moveable
	 * @param ivY is the initial y velocity of the Moveable
	 * @param m is the mass value of the Moveable
	 */
	public BBMoveable(int x1, int y1, int siX, int siY, int ivX, int ivY, int m) {
		super(x1, y1, siX, siY);
		mass = m;
		this.setxVelocity(ivX);
		this.setyVelocity(ivY);
		velocityxTemp = 0;
		velocityyTemp = 0;

	}
	/**
	 * The calculateXMomentum method calculates the momentum in the x direction by multiplying the moveable object's mass with its velocity in the x direction.
	 */
	public void calculateXMomentum() {
		xMomentum = mass * (int) this.getxVelocity();
	}

	/**
	 * The calculateYMomentum method calculates the momentum in the y direction by multiplying the moveable object's mass with its velocity in the y direction.
	 */
	public void calculateYMomentum() {
		yMomentum = mass * (int) this.getyVelocity();
	}

	/**
	 * The calculateXYMomentum method is not used currently. However, it calculates the momentum of the moveable object in the x and y directions.
	 */
	public void calculateXYMomentum() {
		calculateXMomentum();
		calculateYMomentum();

	}

	/**
	 * The calculateAccelerationX method is not used and is currently unfinished.
	 */
	//public void calculateAccelerationX() {
	//	accelerationX = this.getxVelocity();
	//}

	/**
	 * The calculateAccelerationY method is not used and is currently unfinished.
	 */
	//public void calculateAccelerationY() {
	//	accelerationY = this.getyVelocity();
	//}

	/**
	 * The calculateXForce method calculates the force in the x direction based on the moveable object's mass and x acceleration.
	 */
	public void calculateXForce() {
		forceX = mass * accelerationX;
	}

	/**
	 * The calculateYForce method calculates the force in the y direction based on the moveable object's mass and y acceleration.
	 */
	public void calculateYForce() {
		forceY = mass * accelerationY;
	}

	/**
	 * The calculateXYForce is not used in the current iteration of the game. However, it does call the methods used to calculate the force values for the x and y direction.
	 */
	public void calculateXYForce() {
		calculateXForce();
		calculateYForce();
	}

	/**
	 * 
	 * The updateVelocityX method updates the X velocity of the moveable object. It
	 * does this automatically by taking the acceleration in the X direction and
	 * adding that to the X velocity. This method also automatically checks that the
	 * velocity is not above the threshold given by MAXSPEEDX
	 * 
	 */
	public void updateVelocityX() {
		velocityxTemp = this.getxVelocity();
		if (Math.abs(velocityxTemp + accelerationX) <= this.getMAXSPEEDX()) {
			this.setxVelocity(velocityxTemp +  accelerationX);
		} else {
			if (velocityxTemp >= 0) {
				this.setxVelocity(this.getMAXSPEEDX());
			} else {
				this.setxVelocity(this.getMAXSPEEDX() * -1);
			}
			// System.out.println("MAX SPEED HAS BEEN REACHED");
		}

	}

	/*
	 * The updateVelocityY method updates the Y velocity of the moveable object. It
	 * does this automatically by taking the acceleration in the Y direction and
	 * adding that to the Y velocity. This method also automatically checks that the
	 * velocity is not above the threshold given by MAXSPEEDX
	 */
	/**
	 * 
	 * The updateVelocityY method updates the Y velocity of the moveable object. It
	 * does this automatically by taking the acceleration in the Y direction and
	 * adding that to the Y velocity. This method also automatically checks that the
	 * velocity is not above the threshold given by MAXSPEEDX
	 * 
	 */
	public void updateVelocityY() {
		velocityyTemp = this.getyVelocity();
		if (Math.abs(velocityyTemp + accelerationY) <= this.getMAXSPEEDX()) {
			this.setyVelocity(velocityyTemp + accelerationY);
		} else {
			if (velocityyTemp >= 0) {
				this.setyVelocity(this.getMAXSPEEDX());
			} else {
				this.setyVelocity(this.getMAXSPEEDX() * -1);
			}
		}
	}

	/**
	 * The updateXYVelocity method updates the MoveableObject's x velocity, and y
	 * velocity.
	 */
	public void updateXYVelocity() {
		updateVelocityX();
		updateVelocityY();
	}

	/**
	 * @return the xMomentum
	 */
	public int getxMomentum() {
		return xMomentum;
	}

	/**
	 * @param xMomentum
	 *            the xMomentum to set
	 */
	public void setxMomentum(int xMomentum) {
		this.xMomentum = xMomentum;
	}

	/**
	 * @return the yMomentum
	 */
	public int getyMomentum() {
		return yMomentum;
	}

	/**
	 * @param yMomentum
	 *            the yMomentum to set
	 */
	public void setyMomentum(int yMomentum) {
		this.yMomentum = yMomentum;
	}

	/**
	 * @return the mass
	 */
	public int getMass() {
		return mass;
	}

	/**
	 * @param mass
	 *            the mass to set
	 */
	public void setMass(int mass) {
		this.mass = mass;
	}

	/**
	 * @return the forceX
	 */
	public int getForceX() {
		return forceX;
	}

	/**
	 * @param forceX
	 *            the forceX to set
	 */
	public void setForceX(int forceX) {
		this.forceX = forceX;
	}

	/**
	 * @return the forceY
	 */
	public int getForceY() {
		return forceY;
	}

	/**
	 * @param forceY
	 *            the forceY to set
	 */
	public void setForceY(int forceY) {
		this.forceY = forceY;
	}

	/**
	 * @return the accelerationX
	 */
	public int getAccelerationX() {
		return accelerationX;
	}

	/**
	 * @param accelerationX
	 *            the accelerationX to set
	 */
	public void setAccelerationX(int accelerationX) {
		this.accelerationX = accelerationX;
	}

	/**
	 * @return the accelerationY
	 */
	public int getAccelerationY() {
		return accelerationY;
	}

	/**
	 * @param accelerationY
	 *            the accelerationY to set
	 */
	public void setAccelerationY(int accelerationY) {
		this.accelerationY = accelerationY;
	}

	/**
	 * The updateNextInterval method calls methods to update the moveable's x and y
	 * position, as well as its x and y velocities
	 */
	public void updateNextInterval() {
		this.updateXpos();
		this.updateYpos();
		this.updateVelocityX();
		this.updateVelocityY();
	}



}
