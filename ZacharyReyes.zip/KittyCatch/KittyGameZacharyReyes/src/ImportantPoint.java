import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

/**
 * The ImportantPoint class creates our ImportantPoint objects. It is used as our 'points' icons for the game.
 * 
 * @author Zachary Reyes
 *
 */
public class ImportantPoint extends BBElement {
	
	private boolean isDetected;
	private int previousTick;
	private int imageNum;
	private ArrayList<BufferedImage> imageList;
	/**
	 * @return the isDetected
	 */
	public boolean isDetected() {
		return isDetected;
	}

	/**
	 * @param isDetected the isDetected to set
	 */
	public void setDetected(boolean isDetected) {
		this.isDetected = isDetected;
	}

	/**
	 * 
	 * @param x is the initial x position of the IP
	 * @param y is the initial y position of the IP
	 * @param sx is the width of the IP
	 * @param sy is the height of the IP
	 * 
	 * The ImportantPoint constructor builds a new IP. isDetected is set to false when the object is created.
	 */
	public ImportantPoint(int x, int y, int sx, int sy, ToolBox james) {
		super(x, y, sx, sy);
		isDetected = false;
		previousTick = 0;
		imageNum = 0;
		imageList = james.getImageFromHash("CryingKitty");
	}
	
	/**
	 * 
	 * @param gui is the Graphics object to be used for drawing
	 * 
	 * The draw method uses a Graphics object to draw an IP on the screen. The default internal color is PINK, and the default outline color is MAGENTA.
	 */
	public void draw(Graphics gui, int ugh) {
		
		if (!isDetected && (imageList == null)) {
		gui.setColor(Color.PINK);
		gui.fillRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		gui.setColor(Color.MAGENTA);
		gui.drawRect(this.getxPos(), this.getyPos(), this.getxSize(), this.getySize());
		} else if (!isDetected && !(imageList == null)) {
			
			gui.drawImage(imageList.get(imageNum), this.getxPos(), this.getyPos(), this.getxSize(), this.getySize(), null);
			determineIfNextAnimation(ugh);
		}
	}
	
	private void determineIfNextAnimation(int jk) {
		 
		if ((Math.abs(previousTick - jk)) >= 3) {
			previousTick = jk;
			if (imageNum == imageList.size() - 1) {
					imageNum = 0;
			} else {
				imageNum++;
			}
		}
	}
	/**
	 * 
	 * @return int Points
	 * The applyPoints method returns an integer value that is used for the score counter in the GameRun class.
	 */
	public int applyPoints() {
		if (isDetected == false) {
			isDetected = true;
			return 1000;
		} else {
			return 0;
		}
	}
	
}
